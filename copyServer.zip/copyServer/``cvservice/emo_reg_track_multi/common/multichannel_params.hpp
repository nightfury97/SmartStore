// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#pragma once

#include <string>
#include <vector>
#include <gflags/gflags.h>

/// @brief Message for help argument
static const char help_message[] = "Print a usage message";


/// @brief Message for performance counters
static const char performance_counter_message[] = "Optional. Enable per-layer performance report";

/// @brief Message for GPU custom kernels descriptions
static const char custom_cldnn_message[] = "Required for GPU custom kernels. "\
"Absolute path to an .xml file with the kernels descriptions";

/// @brief Message for user library argument
static const char custom_cpu_library_message[] = "Required for CPU custom layers. " \
"Absolute path to a shared library with the kernels implementations";

/// @brief Message for not showing a processed video
static const char no_show_processed_video[] = "Optional. Do not show processed video.";

/// @brief Message for the number of camera inputs
static const char num_cameras[] = "Optional. Maximum number of processed camera inputs (web cameras)";

/// @brief Message for batch size
static const char batch_size[] = "Optional. Batch size for processing (the number of frames processed per infer request)";

/// @brief Message for the number of infer requests
static const char num_infer_requests[] = "Optional. Number of infer requests";

/// @brief Message for inputs queue size
static const char input_queue_size[] = "Optional. Frame queue size for input channels";

/// @brief Message for FPS measurement sampling period
static const char fps_sampling_period[] = "Optional. FPS measurement sampling period between timepoints in msec";

/// @brief Message for the number of sampling periods
static const char num_sampling_periods[] = "Optional. Number of sampling periods";

/// @brief Message for enabling statistics output
static const char show_statistics[] = "Optional. Enable statistics report";

/// @brief Message for enabling channel duplication
static const char duplication_channel_number[] = "Optional. Enable and specify the number of channels additionally copied from real sources";

/// @brief Message for enabling real input FPS
static const char real_input_fps[] = "Optional. Disable input frames caching, for maximum throughput pipeline";

/// @brief Message for enabling input video
static const char input_video[] = "Optional. Specify full path to input video files";

/// \brief Define a flag for showing help message <br>
DEFINE_bool(h, false, help_message);



/// \brief Define a flag to enable per-layer performance report <br>
DEFINE_bool(pc, false, performance_counter_message);

/// @brief GPU custom kernels path <br>
/// Default is ./lib
DEFINE_string(c, "", custom_cldnn_message);

/// @brief Absolute path to CPU library with user layers <br>
/// It is a optional parameter
DEFINE_string(l, "", custom_cpu_library_message);

/// \brief Flag to disable showing processed video<br>
/// It is an optional parameter
DEFINE_bool(no_show, false, no_show_processed_video);

/// \brief Flag to specify the number of expected input channels<br>
/// It is an optional parameter
DEFINE_uint32(nc, 0, num_cameras);

/// \brief Flag to specify batch size<br>
/// It is an optional parameter
DEFINE_uint32(bs, 1, batch_size);

/// \brief Flag to specify the number of infer requests<br>
/// It is an optional parameter
DEFINE_uint32(nireq, 5, num_infer_requests);

/// \brief Flag to specify the number of expected input channels<br>
/// It is an optional parameter
DEFINE_uint32(n_iqs, 5, input_queue_size);

/// \brief Flag to specify FPS measurement sampling period<br>
/// It is an optional parameter
DEFINE_uint32(fps_sp, 1000, fps_sampling_period);

/// \brief Flag to specify the number of sampling periods<br>
/// It is an optional parameter
DEFINE_uint32(n_sp, 10, num_sampling_periods);

/// \brief Flag to enable statisics output<br>
/// It is an optional parameter
DEFINE_bool(show_stats, false, show_statistics);

/// \brief Flag to enable and specify the number of channels additionally copied from real sources<br>
/// It is an optional parameter
DEFINE_uint32(duplicate_num, 0, duplication_channel_number);

/// \brief Flag to enable real input FPS<br>
/// It is an optional parameter
DEFINE_bool(real_input_fps, false, real_input_fps);

/// \brief Define parameter for input video files <br>
/// It is a optional parameter
DEFINE_string(i, "", input_video);










/// @brief message for model arguments
static const char face_detection_model_message[] = "Required. Path to the Pedestrian Detection Retail model (.xml) file.";
static const char face_reid_model_message[] = "Required. Path to the Pedestrian Reidentification Retail model (.xml) file.";
static const char head_pose_model_message[] = "Optional. Path to an .xml file with a trained Head Pose Estimation model.";
static const char emotions_model_message[] = "Optional. Path to an .xml file with a trained Emotions Recognition model.";
static const char facial_landmarks_model_message[] = "Optional. Path to an .xml file with a trained Facial Landmarks Estimation model.";
static const char age_gender_model_message[] = "Optional. Path to an .xml file with a trained Age/Gender Recognition model.";

/// @brief message for assigning Pedestrian detection inference to device
static const char target_device_message_detection[] = "Optional. Specify the target device for face detection "
                                                      "(CPU, GPU, FPGA, HDDL, MYRIAD, or HETERO). ";

/// @brief message for assigning Pedestrian Reidentification retail inference to device
static const char target_device_message_reid[] = "Optional. Specify the target device for face reidentification "
                                                 "(CPU, GPU, FPGA, HDDL, MYRIAD, or HETERO). ";

/// @brief Message for assigning head pose calculation to device
static const char target_device_message_hp[] = "Optional. Target device for Head Pose Estimation network "
                                               "(CPU, GPU, FPGA, HDDL, MYRIAD, or HETERO). ";

/// @brief Message for assigning age/gender calculation to device
static const char target_device_message_ag[] = "Optional. Target device for Age/Gender Recognition network (CPU, GPU, FPGA, HDDL, or MYRIAD). " \
"The demo will look for a suitable plugin for a specified device.";

/// @brief Message for assigning emotions calculation to device
static const char target_device_message_em[] = "Optional. Target device for Emotions Recognition network (CPU, GPU, FPGA, HDDL, or MYRIAD). " \
"The demo will look for a suitable plugin for a specified device.";

/// @brief Message for assigning Facial Landmarks Estimation network to device
static const char target_device_message_lm[] = "Optional. Target device for Facial Landmarks Estimation network (CPU, GPU, FPGA, HDDL, or MYRIAD). " \
"The demo will look for a suitable plugin for device specified.";


/// @brief Message for faces gallery path
static const char reid_gallery_path_message[] = "Optional. Path to a faces gallery in .json format.";

/// @brief Message crop gallery
static const char crop_gallery_message[] = "Optional. Crop images during faces gallery creation.";

/// @brief Message for cosine distance threshold for face reidentification
static const char threshold_output_message_face_reid[] = "Optional. Cosine distance threshold between two vectors for face reidentification.";

/// @brief Message for minumum input size for faces database registration.
static const char min_size_fr_reg_output_message[] = "Optional. Minimum input size for faces during database registration.";


/// @brief Message for the maximum number of simultaneously processed faces for Age Gender network
static const char num_batch_ag_message[] = "Optional. Number of maximum simultaneously processed faces for Age/Gender Recognition network " \
"(by default, it is 16)";

/// @brief Message for the maximum number of simultaneously processed faces for Head Pose network
static const char num_batch_hp_message[] = "Optional. Number of maximum simultaneously processed faces for Head Pose Estimation network " \
"(by default, it is 16)";

/// @brief Message for the maximum number of simultaneously processed faces for Emotions network
static const char num_batch_em_message[] = "Optional. Number of maximum simultaneously processed faces for Emotions Recognition network " \
"(by default, it is 16)";

/// @brief Message for the maximum number of simultaneously processed faces for Facial Landmarks Estimation network
static const char num_batch_lm_message[] = "Optional. Number of maximum simultaneously processed faces for Facial Landmarks Estimation network " \
"(by default, it is 16)";



/// @brief Message for dynamic batching support for HeadPose net
static const char dyn_batch_hp_message[] = "Optional. Enable dynamic batch size for Head Pose Estimation network";

/// @brief Message for dynamic batching support for AgeGender net
static const char dyn_batch_ag_message[] = "Optional. Enable dynamic batch size for Age/Gender Recognition network";

/// @brief Message for dynamic batching support for Emotions net
static const char dyn_batch_em_message[] = "Optional. Enable dynamic batch size for Emotions Recognition network";

/// @brief Message for dynamic batching support for Facial Landmarks Estimation network
static const char dyn_batch_lm_message[] = "Optional. Enable dynamic batch size for Facial Landmarks Estimation network";



/// @brief Message for probability threshold argument for face detections
static const char face_threshold_output_message[] = "Optional. Probability threshold for face detections.";



/// @brief Define parameter for face detection model file <br>
/// It is a required parameter
DEFINE_string(m_det, "", face_detection_model_message);

/// @brief Define parameter for facial landmark model file <br>
/// It is a required parameter
DEFINE_string(m_lm, "", facial_landmarks_model_message);

/// \brief Define parameter for Face Detection  model file<br>
/// It is a optional parameter
DEFINE_string(m_ag, "", age_gender_model_message);

/// \brief Define parameter for Face Detection model file<br>
/// It is a optional parameter
DEFINE_string(m_em, "", emotions_model_message);

/// \brief Define parameter for Face Detection  model file<br>
/// It is a optional parameter
DEFINE_string(m_hp, "", head_pose_model_message);

/// @brief Define parameter for face reidentification model file <br>
/// It is a required parameter
DEFINE_string(m_reid, "", face_reid_model_message);


/// @brief device the target device for face detection infer on <br>
DEFINE_string(d_det, "CPU", target_device_message_detection);

/// @brief device the target device for face reidentification infer on <br>
DEFINE_string(d_reid, "CPU", target_device_message_reid);

/// @brief device the target device for facial landnmarks regression infer on <br>
DEFINE_string(d_lm, "CPU", target_device_message_lm);

/// \brief Define parameter for target device for Age/Gender Recognition network<br>
DEFINE_string(d_ag, "CPU", target_device_message_ag);

/// \brief Define parameter for target device for Emotions Recognition network<br>
DEFINE_string(d_em, "CPU", target_device_message_em);

/// @brief Define parameter for target device for Head Pose Estimation network<br>
DEFINE_string(d_hp, "CPU", target_device_message_hp);


/// @brief Define probability threshold for face detections <br>
/// It is an optional parameter
DEFINE_double(t_det, 0.6, face_threshold_output_message);

/// @brief Path to a faces gallery for reid <br>
/// It is a optional parameter
DEFINE_string(fg, "", reid_gallery_path_message);

/// @brief Path to a faces gallery for reid <br>
/// It is a optional parameter
DEFINE_string(fg_uncheck, "", reid_gallery_path_message);

/// @brief Flag to enable image cropping during database creation<br>
/// It is an optional parameter
DEFINE_bool(crop_gallery, false, crop_gallery_message);

/// @brief Define cosine distance threshold for face reid <br>
/// It is an optional parameter
DEFINE_double(t_reid, 0.7, threshold_output_message_face_reid);

/// @brief Minimum input image width & heigh for successful face registration<br>
/// It is an optional parameter
DEFINE_int32(min_size_fr, 128, min_size_fr_reg_output_message);


/// \brief Define parameter for maximum batch size for Age/Gender Recognition network<br>
DEFINE_uint32(n_ag, 16, num_batch_ag_message);

/// \brief Define parameter to enable dynamic batch size for Age/Gender Recognition network<br>
DEFINE_bool(dyn_ag, false, dyn_batch_ag_message);

/// \brief Define parameter for maximum batch size for Head Pose Estimation network<br>
DEFINE_uint32(n_hp, 16, num_batch_hp_message);

/// \brief Define parameter to enable dynamic batch size for Head Pose Estimation network<br>
DEFINE_bool(dyn_hp, false, dyn_batch_hp_message);

/// \brief Define parameter for maximum batch size for Emotions Recognition network<br>
DEFINE_uint32(n_em, 16, num_batch_em_message);

/// \brief Define parameter to enable dynamic batch size for Emotions Recognition network<br>
DEFINE_bool(dyn_em, false, dyn_batch_em_message);

/// \brief Define parameter for maximum batch size for Facial Landmarks Estimation network<br>
DEFINE_uint32(n_lm, 16, num_batch_em_message);

/// \brief Define parameter to enable dynamic batch size for Facial Landmarks Estimation network<br>
DEFINE_bool(dyn_lm, false, dyn_batch_em_message);



/// @brief message for enabling input video
static const char source_stream[] = "Optional. Specify full url to stream video";

/// \brief Define parameter for input video files <br>
/// It is a optional parameter
DEFINE_string(s, "", source_stream);



/// @brief Message for auto_reg argument
static const char auto_reg_message[] = "Optional. Enable auto registration of new identities";


/// @brief Message for smooth argument
static const char no_smooth_output_message[] = "Optional. Do not smooth person attributes";

/// @brief Message for smooth argument
static const char no_show_emotion_bar_message[] = "Optional. Do not show emotion bar";


DEFINE_bool(draw_track, false, "");
DEFINE_bool(auto_reg, false, auto_reg_message);

DEFINE_double(scale_show, 1, "");
DEFINE_double(scale_det, 0.08, "");
DEFINE_double(fps, -1, "");

/// \brief Define a flag to disable smoothing person attributes<br>
/// It is an optional parameter
DEFINE_bool(no_smooth, false, no_smooth_output_message);

DEFINE_bool(no_show_emotion_bar, false, no_show_emotion_bar_message);


/// @brief message for output log
static const char output_log_message[] = "Optional. The file name to write output log file with results of face tracking. "
                                         "The format of the log file is compatible with MOTChallenge format.";

/// @brief Define output log path to store tracking results <br>
/// It is an optional parameter
DEFINE_string(out, "", output_log_message);




/// @brief Message for asynchronous mode
static const char async_message[] = "Optional. Enable asynchronous mode";

/// @brief Message raw output flag
static const char raw_output_message[] = "Optional. Output Inference results as raw values.";

/// @brief Flag to output raw pipeline results<br>
/// It is an optional parameter
DEFINE_bool(r, false, raw_output_message);

/// \brief Define a flag to enable aynchronous execution<br>
/// It is an optional parameter
DEFINE_bool(async, false, async_message);




/// @brief Message for face enlarge coefficient argument
static const char bb_enlarge_coef_output_message[] = "Optional. Coefficient to enlarge/reduce the size of the bounding box around the detected face";

/// @brief Message for shifting coefficient by dx for detected faces
static const char dx_coef_output_message[] = "Optional. Coefficient to shift the bounding box around the detected face along the Ox axis";

/// @brief Message for shifting coefficient by dy for detected faces
static const char dy_coef_output_message[] = "Optional. Coefficient to shift the bounding box around the detected face along the Oy axis";


/// \brief Define a parameter to shift face bounding box by Ox for more robust operation of face analytics networks<br>
/// It is an optional parameter
DEFINE_double(dx_coef, 1, dx_coef_output_message);

/// \brief Define a parameter to shift face bounding box by Oy for more robust operation of face analytics networks<br>
/// It is an optional parameter
DEFINE_double(dy_coef, 1, dy_coef_output_message);

/// \brief Define a parameter to enlarge the bounding box around the detected face for more robust operation of face analytics networks<br>
/// It is an optional parameter
DEFINE_double(bb_enlarge_coef, 1.2, bb_enlarge_coef_output_message);

