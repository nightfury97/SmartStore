// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include <memory>
#include <string>
#include <list>
#include <vector>
#include <map>
#include <algorithm>
#include <math.h>

#include "visualizer.hpp"

Visualizer::Visualizer(bool enabled, cv::VideoWriter &writer, std::vector<std::string> const &emotionNames, std::vector<int> const &emotionCodes, int leftPadding, int rightPadding, int topPadding, int bottomPadding, cv::Size padding, cv::Size textSize, int textBaseline, int textThickness, double textScale, cv::Size emotionBarSize)
    : enabled_(enabled), writer_(writer),
      emotionNames(emotionNames), emotionCodes(emotionCodes),
      rect_scale_x_(1), rect_scale_y_(1),
      nxcells(0), nycells(0), xstep(0), ystep(0), leftPadding(leftPadding),
      rightPadding(rightPadding), topPadding(topPadding), bottomPadding(bottomPadding), frameCounter(0),
      padding(padding), textSize(textSize), textBaseline(textBaseline), textThickness(textThickness), textScale(textScale), emotionBarSize(emotionBarSize)
{
    if (!enabled_)
    {
        return;
    }
    ystep = (emotionNames.size() < 2) ? 0 : (emotionBarSize.height - 2 * padding.height - textSize.height) / (emotionNames.size() - 1);

    // cv::namedWindow(main_window_name_);
}

void Visualizer::SetWriter(cv::VideoWriter &writer)
{
    writer_ = writer;
}

cv::Size Visualizer::GetOutputSize(const cv::Size &input_size)
{
    if (input_size.width > max_input_width_)
    {
        float ratio = static_cast<float>(input_size.height) / input_size.width;
        return cv::Size(max_input_width_, cvRound(ratio * max_input_width_));
    }
    return input_size;
}

void Visualizer::SetFrame_orig(const cv::Mat &frame)
{
    if (!enabled_ && !writer_.isOpened())
    {
        return;
    }

    frame_orig_ = frame.clone();
}

void Visualizer::SetFrame(const cv::Mat &frame)
{
    if (!enabled_ && !writer_.isOpened())
    {
        return;
    }

    frame_ = frame.clone();
    // frame_orig_ = frame.clone();
    rect_scale_x_ = 1;
    rect_scale_y_ = 1;
    // cv::Size new_size = GetOutputSize(frame_.size());
    // if (new_size != frame_.size())
    // {
    //     rect_scale_x_ = static_cast<float>(new_size.height) / frame_.size().height;
    //     rect_scale_y_ = static_cast<float>(new_size.width) / frame_.size().width;
    //     cv::resize(frame_, frame_, new_size);
    // }
}

void Visualizer::GetCurrentframe(cv::Mat &frame)
{
    frame = frame_.clone();
}

cv::Mat Visualizer::GetCurrentframe()
{
    // frame = frame_.clone();
    return frame_.clone();
}

void Visualizer::Show() const
{
    if (enabled_)
    {
        cv::imshow(main_window_name_, frame_);
    }

    if (writer_.isOpened())
    {
        cv::Mat frame_write;
        cv::resize(frame_, frame_write, cv::Size(out_width, out_height));
        writer_ << frame_write;
    }
}

void Visualizer::DrawObject(cv::Rect rect, const std::string &label_to_draw,
                            const cv::Scalar &text_color, const double &fontScale, 
                            const cv::Scalar &bbox_color, const int bbox_linewidth,
                            bool plot_bg)
{
    if (!enabled_ && !writer_.isOpened())
    {
        return;
    }

    if (rect_scale_x_ != 1 || rect_scale_y_ != 1)
    {
        rect.x = cvRound(rect.x * rect_scale_x_);
        rect.y = cvRound(rect.y * rect_scale_y_);

        rect.height = cvRound(rect.height * rect_scale_y_);
        rect.width = cvRound(rect.width * rect_scale_x_);
    }

    cv::rectangle(frame_, rect, bbox_color, bbox_linewidth);

    DrawLabel(rect, label_to_draw, text_color, fontScale, bbox_color, plot_bg, 1);
}

void Visualizer::DrawLabel(cv::Rect rect, const std::string &label_to_draw,
                            const cv::Scalar &text_color, const double &fontScale,
                            const cv::Scalar &bbox_color, bool plot_bg, double opacity)
{
    if (!enabled_ && !writer_.isOpened())
    {
        return;
    }

    if (rect_scale_x_ != 1 || rect_scale_y_ != 1)
    {
        rect.x = cvRound(rect.x * rect_scale_x_);
        rect.y = cvRound(rect.y * rect_scale_y_);

        rect.height = cvRound(rect.height * rect_scale_y_);
        rect.width = cvRound(rect.width * rect_scale_x_);
    }

    int baseLine = 0;
    const cv::Size label_size =
            cv::getTextSize(label_to_draw, cv::FONT_HERSHEY_PLAIN, fontScale, 1, &baseLine);
    if (plot_bg && !label_to_draw.empty())
    {
        if (opacity == 1) {
            cv::rectangle(frame_, cv::Point(rect.x, rect.y - label_size.height - baseLine),
                        cv::Point(rect.x + label_size.width, rect.y),
                        bbox_color, cv::FILLED);
        } else {
            // need to make sure these points are in frame if using this.
            // draw label of emotion bar only, so it is sure that the label is in the frame, no need to check.
            cv::Mat tmp = frame_(cv::Rect(cv::Point(rect.x, rect.y - label_size.height - baseLine), cv::Point(rect.x + label_size.width, rect.y)));
            cv::addWeighted(tmp, 1.f - opacity, bbox_color, opacity, 0, tmp);
        }
    }
    if (!label_to_draw.empty())
    {
        cv::putText(frame_, label_to_draw, cv::Point(rect.x, rect.y - baseLine + 4), cv::FONT_HERSHEY_PLAIN, fontScale,
                    text_color, 1, cv::LINE_AA);
    }
}

void Visualizer::DrawRect(cv::Rect rect, const cv::Scalar &bbox_color, int bbox_linewidth)
{
    if (!enabled_ && !writer_.isOpened())
    {
        return;
    }

    if (rect_scale_x_ != 1 || rect_scale_y_ != 1)
    {
        rect.x = cvRound(rect.x * rect_scale_x_);
        rect.y = cvRound(rect.y * rect_scale_y_);

        rect.height = cvRound(rect.height * rect_scale_y_);
        rect.width = cvRound(rect.width * rect_scale_x_);
    }
    cv::rectangle(frame_, rect, bbox_color, bbox_linewidth);
}

void Visualizer::DrawFPS(const float fps, const cv::Scalar &color)
{
    if (enabled_)
    {
        cv::putText(frame_,
                    std::to_string(static_cast<int>(fps)) + " fps",
                    cv::Point(10, 50), cv::FONT_HERSHEY_SIMPLEX, 2,
                    color, 2, cv::LINE_AA);
    }
}

void Visualizer::Finalize() const
{
    if (enabled_)
    {
        cv::destroyWindow(main_window_name_);
    }

    if (writer_.isOpened())
    {
        writer_.release();
    }
}

cv::Point Visualizer::findCellForEmotionBar()
{
    cv::Point p;
    int yEnd = std::max(nycells / 2, 1);
    for (p.y = 0; p.y < yEnd; p.y++)
    {
        for (p.x = 0; p.x < nxcells; p.x++)
        {
            if (drawMap.at<uchar>(p.y, p.x) == 0)
            {
                return p;
            }
        }
    }

    for (p.x = 0, p.y = yEnd; p.y < nycells; p.y++)
    {
        if (drawMap.at<uchar>(p.y, p.x) == 0)
        {
            return p;
        }
    }

    for (p.x = nxcells - 1, p.y = yEnd; p.y < nycells; p.y++)
    {
        if (drawMap.at<uchar>(p.y, p.x) == 0)
        {
            return p;
        }
    }

    return cv::Point(-1, -1);
}

void Visualizer::DrawEmotionBar(int object_id, int face_idx, cv::Rect rect, std::vector<float> tot_frames_emos, std::vector<float> prob_frames_emos, cv::Scalar fgcolor, cv::Scalar bgcolor)
{
    // std::cout<<"emotionBarSize.width="<<emotionBarSize.width<<" | face_idx="<<face_idx<<" | leftPadding="<<leftPadding<<" | emotionBarSize.width * face_idx="<<(emotionBarSize.width * face_idx)<<std::endl;

    // int nMax = 4;
    int nMax = floor(frame_.cols / (emotionBarSize.width + leftPadding));

    double orgx = (emotionBarSize.width + leftPadding) * face_idx;
    double orgy = frame_.rows - emotionBarSize.height - bottomPadding;
    // if (orgx + emotionBarSize.width > frame_.cols) {
    if (face_idx > nMax)
    {
        orgx = (emotionBarSize.width + leftPadding) * (face_idx - nMax - 1);
        orgy = frame_.rows - (emotionBarSize.height + bottomPadding) * (floor(face_idx / nMax) +1);
    }
    cv::Point org(orgx, orgy);

    double opacity = 0.5;
    DrawLabel(cv::Rect(org.x, org.y, 30, 20), "["+std::to_string(face_idx)+"]", fgcolor, 1.2, bgcolor, true, opacity);

    cv::Mat tmp = frame_(cv::Rect(org.x, org.y, emotionBarSize.width, emotionBarSize.height));
    cv::addWeighted(tmp, 1.f - opacity, bgcolor, opacity, 0, tmp);

    auto drawEmotion = [&](int n, std::string text, float prob, float tot) {
        cv::Point torg(org.x + padding.width, org.y + n * ystep + textSize.height + padding.height);

        int textWidth = textSize.width + 10;

        cv::Rect r(torg.x + textWidth, torg.y - textSize.height, emotionBarSize.width - 2 * padding.width - textWidth, textSize.height + textBaseline / 2);

        cv::putText(frame_, text + " (" + std::to_string(static_cast<int>(tot)) + ")", torg, cv::FONT_HERSHEY_COMPLEX_SMALL, textScale, fgcolor, textThickness);
        cv::rectangle(frame_, r, fgcolor, 1);
        // r.width = static_cast<int>(r.width * value / sum);
        r.width = static_cast<int>(r.width * prob);
        cv::rectangle(frame_, r, fgcolor, cv::FILLED);
    };

    for (size_t i = 0; i < emotionCodes.size(); i++)
    {
        int emo_id = static_cast<int>(emotionCodes[i]);
        drawEmotion(i, emotionNames[i], prob_frames_emos[emo_id], tot_frames_emos[emo_id]);
    }

    auto getCorner = [](cv::Rect r) -> cv::Point {
        cv::Point p;
        p.x = r.x + r.width / 2 - 1;
        p.y = r.y + r.height - 1;

        return p;
    };

    cv::Point p0 = getCorner(cv::Rect(org, emotionBarSize));
    cv::Point p1 = getCorner(rect);
    cv::line(frame_, p0, p1, bgcolor);
}
