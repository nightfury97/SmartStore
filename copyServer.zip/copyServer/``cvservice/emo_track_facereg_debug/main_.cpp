// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include "core.hpp"
#include "utils.hpp"
#include "tracker.hpp"
#include "descriptor.hpp"
#include "distance.hpp"
#include "detector.hpp"
#include "image_reader.hpp"
#include "emo_track.hpp"
#include "face.hpp"
#include "visualizer.hpp"
// #include "softmax.hpp"

#include "face_reid.hpp"

#include <gflags/gflags.h>
#include <functional>
#include <iostream>
#include <fstream>
#include <random>
#include <memory>
#include <chrono>
#include <vector>
#include <string>
#include <utility>
#include <algorithm>
#include <iterator>
#include <map>
#include <list>
#include <set>

#include <inference_engine.hpp>

#include <samples/ocv_common.hpp>
#include <samples/slog.hpp>

using namespace InferenceEngine;
using ImageWithFrameIndex = std::pair<cv::Mat, int>;

// C library headers
#include <stdio.h>
#include <string.h>

// Linux headers
#include <fcntl.h>   // Contains file controls like O_RDWR
#include <errno.h>   // Error integer and strerror() function
#include <termios.h> // Contains POSIX terminal control definitions
#include <unistd.h>  // write(), read(), close()

#include "mqtt.hpp"

#include <assert.h>
#include <cassert>
#include <cmath>
#include <exception>
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/stat.h>
#include <time.h>

// #include <experimental/filesystem>
#include <sys/stat.h>
inline bool fexists (const std::string& filename) {
    struct stat buffer;   
    return (stat (filename.c_str(), &buffer) == 0); 
}


std::vector<std::string> gender_txt = {"Nam", "Nu"};

// EmbeddingsGallery face_gallery;
RegistrationStatus autoRegisterIdentity(std::string file_relative_path,
                                        EmbeddingsGallery &face_gallery, FaceDetection &detector,
                                        const VectorCNN &landmarks_det,
                                        const VectorCNN &image_reid,
                                        bool &register_new_person)
{
    std::string template_img_path = FLAGS_fg_uncheck+"/" + file_relative_path;

    std::cout<<"template_img_path= "<<template_img_path<<std::endl;

    bool exist = false;
    while (!exist) {
        exist = fexists(template_img_path);
    
        if (exist) {
            std::cout<<"file exists"<<std::endl;

            cv::Mat image = cv::imread(template_img_path);
            std::cout<<"(w,h)="<<image.cols<<","<<image.rows<<std::endl;

            std::string delimiter = "/";
            std::string label_txt = file_relative_path.substr(0, file_relative_path.find(delimiter));
            std::vector<cv::Mat> embeddings;
            std::cout<<"Registering..."<<std::endl;
            RegistrationStatus reg_new_face = face_gallery.RegisterIdentity(label_txt, image, FLAGS_min_size_fr, true, detector, landmarks_det, image_reid, embeddings);

            if (reg_new_face == RegistrationStatus::SUCCESS) {
                std::cout<<"Editing file "<<FLAGS_fg<<std::endl;

                std::ostringstream text;
                std::ifstream in_file(FLAGS_fg);

                text << in_file.rdbuf();
                std::string str = text.str();
                std::cout<<str<<std::endl;
                std::string str_search = "]}";
                std::string str_replace = "], \""+label_txt+"\": [\""+template_img_path+"\"]}";
                size_t pos = str.find(str_search);
                str.replace(pos, str_search.length(), str_replace);
                in_file.close();

                std::cout<<"Edit file done"<<std::endl;

                std::ofstream out_file(FLAGS_fg);
                out_file << str;
                out_file.close();
            }

            register_new_person = false;

            return reg_new_face;
        } else {
            std::cout<<template_img_path<<" not found. recheck"<<std::endl;
        }
    }
    return RegistrationStatus::FAILURE_LOW_QUALITY;

}

/*=============================================
 * MQTT vars
 *=============================================*/
struct Lambda {
    template<typename Tret, typename T>
    static Tret lambda_ptr_exec(void *context, char *topicName, int topicLen, MQTTClient_message *message) {
        return (Tret) (*(T*)fn<T>())(context, topicName, topicLen, message);
    }

    template<typename Tret = void, typename Tfp = Tret(*)(void*, char*, int, MQTTClient_message*), typename T>
    static Tfp ptr(T& t) {
        fn<T>(&t);
        return (Tfp) lambda_ptr_exec<Tret, T>;
    }

    template<typename T>
    static void* fn(void* new_fn = nullptr) {
        static void* fn;
        if (new_fn != nullptr)
            fn = new_fn;
        return fn;
    }
};

std::string lastTopic;
std::string lastID;
std::string name;
volatile bool performRegistration = false;
volatile bool saveNeeded = false;
volatile bool saveNeeded2 = false;
/*=============== END MQTT ======================*/

bool checkDynamicBatchSupport(const Core &ie, const std::string &device)
{
    try
    {
        if (ie.GetConfig(device, CONFIG_KEY(DYN_BATCH_ENABLED)).as<std::string>() != PluginConfigParams::YES)
            return false;
    }
    catch (const std::exception &error)
    {
        return false;
    }
    return true;
}

void CalcProb(int emo_id, float emo_num, float sum, float &emo_prob, float &max)
{
    // std::cout<<"emo_id="<<emo_id<<std::endl;
    float x = emo_num;

    x *= weights_emos[emo_id];
    if (max < x)
        max = x;

    float weighted = exp(x - max);
    sum += weighted;

    weighted /= sum;
    // x[i] /= sum;
    weighted = round_(weighted);

    emo_prob = weighted;
}

int set_interface_attribs(int fd, int speed, int parity)
{
    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0)
    {
        printf("error %d from tcgetattr", errno);
        return -1;
    }

    cfsetospeed(&tty, speed);
    cfsetispeed(&tty, speed);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8; // 8-bit chars
    // disable IGNBRK for mismatched speed tests; otherwise receive break
    // as \000 chars
    tty.c_iflag &= ~IGNBRK; // disable break processing
    tty.c_lflag = 0;        // no signaling chars, no echo,
                            // no canonical processing
    tty.c_oflag = 0;        // no remapping, no delays
    tty.c_cc[VMIN] = 0;     // read doesn't block
    tty.c_cc[VTIME] = 5;    // 0.5 seconds read timeout

    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl

    tty.c_cflag |= (CLOCAL | CREAD);   // ignore modem controls,
                                       // enable reading
    tty.c_cflag &= ~(PARENB | PARODD); // shut off parity
    tty.c_cflag |= parity;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;

    if (tcsetattr(fd, TCSANOW, &tty) != 0)
    {
        printf("error %d from tcsetattr\n", errno);
        return -1;
    }
    return 0;
}

void set_blocking(int fd, int should_block)
{
    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0)
    {
        printf("error %d from tggetattr\n", errno);
        return;
    }

    tty.c_cc[VMIN] = should_block ? 1 : 0;
    tty.c_cc[VTIME] = 5; // 0.5 seconds read timeout

    if (tcsetattr(fd, TCSANOW, &tty) != 0)
        printf("error %d setting term attributes\n", errno);
}

std::unique_ptr<Tracker>
CreatePedestrianTracker(bool should_keep_tracking_info)
{
    TrackerParams params;

    if (should_keep_tracking_info)
    {
        params.drop_forgotten_tracks = false;
        params.max_num_objects_in_track = -1;
    }

    std::unique_ptr<Tracker> tracker(new Tracker(params));

    // Load reid-model.
    std::shared_ptr<IImageDescriptor> descriptor_fast =
        std::make_shared<ResizedImageDescriptor>(
            cv::Size(16, 32), cv::InterpolationFlags::INTER_LINEAR);
    std::shared_ptr<IDescriptorDistance> distance_fast =
        std::make_shared<MatchTemplateDistance>();

    tracker->set_descriptor_fast(descriptor_fast);
    tracker->set_distance_fast(distance_fast);

    return tracker;
}

std::unique_ptr<Tracker>
CreatePedestrianTracker(const std::string &reid_model,
                        const std::string &reid_weights,
                        CnnConfig reid_config,
                        const InferenceEngine::Core &ie,
                        const std::string &deviceName,
                        bool should_keep_tracking_info)
{
    TrackerParams params;

    if (should_keep_tracking_info)
    {
        params.drop_forgotten_tracks = false;
        params.max_num_objects_in_track = -1;
    }

    std::unique_ptr<Tracker> tracker(new Tracker(params));

    // Load reid-model.
    std::shared_ptr<IImageDescriptor> descriptor_fast =
        std::make_shared<ResizedImageDescriptor>(
            cv::Size(16, 32), cv::InterpolationFlags::INTER_LINEAR);
    std::shared_ptr<IDescriptorDistance> distance_fast =
        std::make_shared<MatchTemplateDistance>();

    tracker->set_descriptor_fast(descriptor_fast);
    tracker->set_distance_fast(distance_fast);

    if (!reid_model.empty() && !reid_weights.empty())
    {
        std::shared_ptr<IImageDescriptor> descriptor_strong =
            std::make_shared<DescriptorIE>(reid_config, ie, deviceName);

        if (descriptor_strong == nullptr)
        {
            THROW_IE_EXCEPTION << "[SAMPLES] internal error - invalid descriptor";
        }
        std::shared_ptr<IDescriptorDistance> distance_strong =
            std::make_shared<CosDistance>(descriptor_strong->size());

        tracker->set_descriptor_strong(descriptor_strong);
        tracker->set_distance_strong(distance_strong);
    }
    else
    {
        std::cout << "WARNING: Either reid model or reid weights "
                  << "were not specified. "
                  << "Only fast reidentification approach will be used." << std::endl;
    }

    return tracker;
}

bool ParseAndCheckCommandLine(int argc, char *argv[])
{
    // ---------------------------Parsing and validation of input args--------------------------------------

    gflags::ParseCommandLineNonHelpFlags(&argc, &argv, true);
    if (FLAGS_h)
    {
        showUsage();
        return false;
    }

    std::cout << "[ INFO ] Parsing input parameters" << std::endl;

    if (FLAGS_i.empty())
    {
        throw std::logic_error("Parameter -i is not set");
    }

    if (FLAGS_m_det.empty())
    {
        throw std::logic_error("Parameter -m_det is not set");
    }

    return true;
}

int main_work(int argc, char **argv)
{
    // int serial_port = open("/dev/ttyUSB0", O_RDWR);

    // if (serial_port < 0)
    // {
    //     printf("Error %i from open: %s\n", errno, strerror(errno));
    // }
    // set_interface_attribs(serial_port, B115200, 0);
    // set_blocking(serial_port, 1);
    //char *s = "ON";
    //write(serial_port, s, sizeof(s));

    std::cout << "InferenceEngine: " << GetInferenceEngineVersion() << std::endl;

    if (!ParseAndCheckCommandLine(argc, argv))
    {
        return 0;
    }

    const char ESC_KEY = 27;
    const cv::Scalar blue_color(255, 0, 0);
    const cv::Scalar brown_color(20, 100, 100);
    const cv::Scalar green_color(11, 138, 100);
    const cv::Scalar dark_green_color(10, 90, 20);
    const cv::Scalar red_color(0, 0, 255);
    const cv::Scalar white_color(255, 255, 255);
    const cv::Scalar pink_color(147, 20, 255);

    // Reading command line parameters.
    auto video_path = FLAGS_i;

    const auto det_model = FLAGS_m_det;
    const auto det_weights = fileNameNoExt(FLAGS_m_det) + ".bin";

    const auto outpath_log_track = (!FLAGS_out.empty() ? FLAGS_out + "/log_track.txt" : "");
    const auto outpath_log = (!FLAGS_out.empty() ? FLAGS_out + "/log.txt" : "");

    auto custom_cpu_library = FLAGS_l;
    auto path_to_custom_layers = FLAGS_c;
    bool should_use_perf_counter = FLAGS_pc;

    bool should_show = !FLAGS_no_show;
    int delay = FLAGS_delay;
    if (!should_show)
        delay = -1;
    should_show = (delay >= 0);

    int first_frame = FLAGS_first;
    int last_frame = FLAGS_last;

    if (first_frame >= 0)
        std::cout << "first_frame = " << first_frame << std::endl;
    if (last_frame >= 0)
        std::cout << "last_frame = " << last_frame << std::endl;

    // ------------------------------------------------------------------
    // 1. Loading Inference Engine
    // ------------------------------------------------------------------
    Core ie;

    std::set<std::string> loadedDevices;
    std::vector<std::pair<std::string, std::string>> cmdOptions = {
        {FLAGS_d_det, FLAGS_m_det},
        {FLAGS_d_ag, FLAGS_m_ag},
        {FLAGS_d_hp, FLAGS_m_hp},
        {FLAGS_d_em, FLAGS_m_em},
        {FLAGS_d_lm, FLAGS_m_lm}};

    for (auto &&option : cmdOptions)
    {
        auto deviceName = option.first;
        auto networkName = option.second;

        if (deviceName.empty() || networkName.empty())
        {
            continue;
        }

        if (loadedDevices.find(deviceName) != loadedDevices.end())
        {
            continue;
        }
        slog::info << "Loading device " << deviceName << slog::endl;
        std::cout << ie.GetVersions(deviceName) << std::endl;

        /** Loading extensions for the CPU device **/
        if ((deviceName.find("CPU") != std::string::npos))
        {
#ifdef WITH_EXTENSIONS
            ie.AddExtension(std::make_shared<Extensions::Cpu::CpuExtensions>(), "CPU");
#endif

            if (!FLAGS_l.empty())
            {
                // CPU(MKLDNN) extensions are loaded as a shared library and passed as a pointer to base extension
                auto extension_ptr = make_so_pointer<IExtension>(FLAGS_l);
                ie.AddExtension(extension_ptr, "CPU");
                slog::info << "CPU Extension loaded: " << FLAGS_l << slog::endl;
            }
        }
        else if (!FLAGS_c.empty())
        {
            // Loading extensions for GPU
            ie.SetConfig({{PluginConfigParams::KEY_CONFIG_FILE, FLAGS_c}}, "GPU");
        }

        loadedDevices.insert(deviceName);
    }

    /** Per-layer metrics **/
    if (FLAGS_pc)
    {
        ie.SetConfig({{PluginConfigParams::KEY_PERF_COUNT, PluginConfigParams::YES}});
    }

    FaceDetection faceDetector(FLAGS_m_det, FLAGS_d_det, 1, false, FLAGS_async, FLAGS_t_det, FLAGS_r,
                               static_cast<float>(FLAGS_bb_enlarge_coef), static_cast<float>(FLAGS_dx_coef), static_cast<float>(FLAGS_dy_coef));
    AgeGenderDetection ageGenderDetector(FLAGS_m_ag, FLAGS_d_ag, FLAGS_n_ag, FLAGS_dyn_ag, FLAGS_async, FLAGS_r);
    EmotionsDetection emotionsDetector(FLAGS_m_em, FLAGS_d_em, FLAGS_n_em, FLAGS_dyn_em, FLAGS_async, FLAGS_r);
    HeadPoseDetection headPoseDetector(FLAGS_m_hp, FLAGS_d_hp, FLAGS_n_hp, FLAGS_dyn_hp, FLAGS_async, FLAGS_r);

    // ------------------------------------------------------------------
    // 2. Reading IR models and loading them to plugins
    // ------------------------------------------------------------------
    /* Disable dynamic batching for face detector as it processes one image at a time */
    Load(faceDetector).into(ie, FLAGS_d_det, false);
    Load(ageGenderDetector).into(ie, FLAGS_d_ag, FLAGS_dyn_ag);
    Load(headPoseDetector).into(ie, FLAGS_d_hp, FLAGS_dyn_hp);
    Load(emotionsDetector).into(ie, FLAGS_d_em, FLAGS_dyn_em);
    // ----------------------------------------------------------------------------------------------------

    const auto reid_model = FLAGS_m_reid;
    const auto reid_weights = fileNameNoExt(FLAGS_m_reid) + ".bin";
    const auto lm_model = FLAGS_m_lm;
    const auto lm_weights = fileNameNoExt(FLAGS_m_lm) + ".bin";

    /* Load face reid */
    CnnConfig reid_config(reid_model, reid_weights);
    reid_config.enabled = !reid_model.empty() && !lm_model.empty();
    reid_config.deviceName = FLAGS_d_reid;
    if (checkDynamicBatchSupport(ie, FLAGS_d_reid))
        reid_config.max_batch_size = 16;
    else
        reid_config.max_batch_size = 1;
    reid_config.ie = ie;
    VectorCNN face_reid(reid_config, ie, FLAGS_d_reid);

    /* Load landmarks detector */
    CnnConfig landmarks_config(lm_model, lm_weights);
    landmarks_config.max_batch_size = 16;
    landmarks_config.enabled = reid_config.enabled && !lm_model.empty();
    landmarks_config.deviceName = FLAGS_d_lm;
    if (checkDynamicBatchSupport(ie, FLAGS_d_lm))
        landmarks_config.max_batch_size = 16;
    else
        landmarks_config.max_batch_size = 1;
    landmarks_config.ie = ie;
    VectorCNN landmarks_detector(landmarks_config, ie, FLAGS_d_lm);

    /* Create face gallery */
    EmbeddingsGallery face_gallery(FLAGS_fg, FLAGS_t_reid, FLAGS_min_size_fr, FLAGS_crop_gallery, faceDetector, landmarks_detector, face_reid);

    if (!reid_config.enabled)
    {
        slog::warn << "Face recognition models are disabled!" << slog::endl;
    }
    else if (!face_gallery.size())
    {
        slog::warn << "Face reid gallery is empty!" << slog::endl;
    }
    else
    {
        slog::info << "Face reid gallery size: " << face_gallery.size() << slog::endl;
    }

    // ------------------------------------------------------------------
    // 3. Connect with frontend
    // ------------------------------------------------------------------
    int handle_msg_stt = -1;
    // auto b = [&]() {return a;};
    // int (*fp)(void*) = lambda_ptr<int>(b);

    bool register_new_person = false;

    auto handleControlMessages = [&](void *context, char *topicName, int topicLen, MQTTClient_message *message) {
        std::string topic = topicName;
        std::string msg = "MQTT message received: " + topic;
        // syslog(LOG_INFO, "%s", msg.c_str());
        std::cout << msg.c_str() << std::endl;

        int i;
        char *payloadptr;
        char *test[256];

        payloadptr = (char *)message->payload;

        if (topic == "commands/name")
        {
            std::string original = std::string(payloadptr);
            size_t s = original.find('"');
            size_t e = original.find('"', s + 1);
            std::string sub = original.substr(s + 1, e - s - 1);
            saveNeeded = true;
            name = sub;
            std::cout<<"name="<<name<<std::endl;
            register_new_person = true;
        }
        return 1;
    };
    int (*fp)(void*, char*, int, MQTTClient_message*) = Lambda::ptr<int>(handleControlMessages);
    mqtt_start(fp);

    mqtt_connect();
    // mqtt_subscribe("commands/register"); //đăng kí nhận dữ liệu
    mqtt_subscribe("commands/name");
    // mqtt_subscribe("commands/name2");

    // ------------------------------------------------------------------
    // 3. Doing inference
    //    Starting inference & calculating performance
    // ------------------------------------------------------------------
    bool should_keep_tracking_info = false;
    std::unique_ptr<Tracker> tracker =
        CreatePedestrianTracker(reid_model, reid_weights, reid_config, ie, FLAGS_d_reid, should_keep_tracking_info);
    // std::unique_ptr<Tracker> tracker =
    //     CreatePedestrianTracker(should_keep_tracking_info);

    // Opening video.
    std::unique_ptr<ImageReader> video =
        ImageReader::CreateImageReaderForPath(video_path);

    PT_CHECK(video->IsOpened()) << "Failed to open video: " << video_path;
    double video_fps = video->GetFrameRate();

    if (first_frame > 0)
        video->SetFrameIndex(first_frame);

    if (should_show)
    {
        std::cout << "To close the application, press 'CTRL+C' or any key with focus on the output window" << std::endl;
    }

    std::ofstream outputFile(outpath_log);

    float work_time_ms = 0.f;
    size_t work_num_frames = 0;

    std::ostringstream out;

    cv::VideoWriter vid_writer;
    cv::Size vid_size(1280, 720);
    // cv::Size vid_size(640, 320);
    if (!FLAGS_out.empty())
    {
        vid_writer = cv::VideoWriter(FLAGS_out + "/out_track.avi", cv::VideoWriter::fourcc('M', 'J', 'P', 'G'), 30.0, vid_size);
    }

    Visualizer sc_visualizer(should_show, vid_writer, EmotionsDetection::emotionsVecTxt, EmotionsDetection::emotionsVec);
    sc_visualizer.out_width = vid_size.width;
    sc_visualizer.out_height = vid_size.height;

    // std::cout << "---FIRST STEP---" << std::endl;
    // std::cout << "Write GREEN to serial port" << std::endl;
    // char *s = "G";
    // write(serial_port, s, 1);

    std::map<int, float> min_dist_by_objectid;
    std::map<int, std::string> final_label_txt;
    std::map<int, std::vector<float>> tot_emos_by_objectid;
    std::map<int, std::vector<float>> prob_emos_by_objectid;
    std::map<int, std::string> final_emo_txt;
    std::map<int, std::vector<int>> tot_gen_by_objectid;
    std::map<int, std::string> final_gen_txt;
    std::map<int, std::string> final_age_txt;

    double scale = FLAGS_scale_det; // 0.05
    double scale_mul = 1 / scale;
    double scale_show = FLAGS_scale_show;
    // double scale_emo = 0.8;
    // double scale_emo_mul = 1 / scale_emo;

    slog::info << "Reading input" << slog::endl;

    std::list<Face::Ptr> faces;

    cv::Mat frame_sm, frame_show;
    TrackedObjects detections_, detections;

    while (true)
    {
        auto started = std::chrono::high_resolution_clock::now();

        auto pair = video->Read();
        cv::Mat frame = pair.first;
        // int frame_idx = pair.second;
        int frame_idx = work_num_frames;

        if (frame.empty())
            break;

        PT_CHECK(frame_idx >= first_frame);

        if ((last_frame >= 0) && (frame_idx > last_frame))
        {
            std::cout << "Frame " << frame_idx << " is greater than last_frame = " << last_frame << " -- break";
            break;
        }

        cv::resize(frame, frame_sm, cv::Size(), scale, scale);
        cv::resize(frame, frame_show, cv::Size(), scale_show, scale_show);

        if (register_new_person) {
            autoRegisterIdentity(name, face_gallery, faceDetector, landmarks_detector, face_reid, register_new_person);
        }

        if (frame_idx % 3 == 0 && !register_new_person)
        {
            faceDetector.submitFrame(frame_sm, frame_idx);
            faceDetector.waitAndFetchResults();
            detections_ = faceDetector.results;

            // timestamp in milliseconds
            uint64_t cur_timestamp = static_cast<uint64_t>(1000.0 / video_fps * frame_idx);
            tracker->Process(frame, detections_, cur_timestamp);

            detections = tracker->TrackedDetectionsWithLabels();
            // std::cout<<"detections.size="<<detections.size()<<" | detections_.size="<<detections_.size()<<std::endl;
        }

        // Drawing colored "worms" (tracks)
        if (FLAGS_draw_track)
        {
            frame_show = tracker->DrawActiveTracks(frame_show, scale_mul * scale_show);
        }
        sc_visualizer.SetFrame(frame_show);
    
        /*==================================================
         * Process 
         *==================================================*/
        bool submitAgeGender = false;
        bool submitEmo = false;
        std::vector<cv::Mat> face_rois, landmarks, embeddings, raw_faces;
        if (frame_idx % 3 == 0 && !register_new_person)
        {
            auto frame_cp = frame.clone();
            // auto frame_copy = frame.clone();

            for (size_t i = 0; i < detections.size(); i++)
            {
                // const auto &detection = detections[i];
                auto rect_orig = detections[i].rect;
                rect_orig.x *= scale_mul;
                rect_orig.y *= scale_mul;
                rect_orig.width *= scale_mul;
                rect_orig.height *= scale_mul;

                if (rect_orig.x < 0)
                    rect_orig.x = 0;
                if (rect_orig.y < 0)
                    rect_orig.y = 0;
                if (rect_orig.x + rect_orig.width > frame.cols)
                    rect_orig.width = frame.cols - rect_orig.x;
                if (rect_orig.y + rect_orig.height > frame.rows)
                    rect_orig.height = frame.rows - rect_orig.y;

                cv::Mat face = frame_cp(rect_orig);
                face_rois.push_back(face);
                raw_faces.push_back(face);

                headPoseDetector.enqueue(face);
                headPoseDetector.submitRequest();
                headPoseDetector.wait();

                // Update to scale show
                rect_orig.x *= scale_show;
                rect_orig.y *= scale_show;
                rect_orig.width *= scale_show;
                rect_orig.height *= scale_show;

                if (rect_orig.x < 0)
                    rect_orig.x = 0;
                if (rect_orig.y < 0)
                    rect_orig.y = 0;
                if (rect_orig.x + rect_orig.width > frame_show.cols)
                    rect_orig.width = frame_show.cols - rect_orig.x;
                if (rect_orig.y + rect_orig.height > frame_show.rows)
                    rect_orig.height = frame_show.rows - rect_orig.y;
                detections[i].rect_orig = rect_orig;
            }

            /* Align faces and calculate embeddings */
            landmarks_detector.Compute(face_rois, &landmarks, cv::Size(2, 5));
            AlignFaces(&face_rois, &landmarks);
            face_reid.Compute(face_rois, &embeddings);

            /* Find id in gallery by embeddings */
            auto ids = face_gallery.GetIDsByEmbeddings(embeddings);


            for (size_t i = 0; i < detections.size(); i++)
            {
                /* Face recognition result */
                int label = ids.empty() ? EmbeddingsGallery::unknown_id : ids[i].id;
                std::string label_txt = face_gallery.GetLabelByID(label);

                // std::cout<<"label="<<label<<" | dist="<<ids[i].dist<<" | label_txt="<<label_txt<<std::endl;

                detections[i].label = label;
                detections[i].label_txt = label_txt;
                detections[i].dist = ids[i].dist;


                bool goodFace = false;
                const auto &raw_face = raw_faces[i];

                /* Get pose details */
                const auto headPose = headPoseDetector[i];

                double yaw = headPose.angle_y;
                double pitch = headPose.angle_p;
                double roll = headPose.angle_r;

                // std::cout<<"\n> ["<<detections[i].object_id<<"] (y,p,r)="<<yaw<<","<<pitch<<","<<roll<<std::endl;

                if (int(yaw) > -25 && int(yaw) < 25 && int(pitch) > -25 && int(pitch) < 25 && int(roll) > -25 && int(roll) < 25)
                {
                    goodFace = true;
                }

                // Enque age_gender and emotion detector 
                // if (goodFace && (raw_face.cols >= 64 && raw_face.rows >= 64))
                if (true)
                {
                    if (!FLAGS_m_ag.empty())
                    {
                        // ageGenderDetector.enqueue(face_emo);
                        ageGenderDetector.enqueue(raw_face);
                        // std::cout<<"\t ["<<detections[i].object_id<<"] enqueued"<<std::endl;
                        // cv::imshow(std::to_string(detections[i].object_id), raw_face);
                        
                        submitAgeGender = true;
                    }
                    if (!FLAGS_m_em.empty())
                    {
                        // emotionsDetector.enqueue(face_emo);
                        emotionsDetector.enqueue(raw_face);
                        submitEmo = true;
                    }
                }
                else
                {
                    // std::cout << "Bad face" << std::endl;
                }
            
            }

        }


        if (frame_idx % 3 == 0 && !register_new_person) {
            /* Submit age_gender and emo */
            // std::cout<<"\t ["<<detections[i].object_id<<"] goodFace="<<goodFace<<" | "<<detections[i].submitAgeGender<<std::endl;
            if (submitAgeGender)
            {
                ageGenderDetector.submitRequest();
                ageGenderDetector.wait();
            }
            if (submitEmo)
            {
                emotionsDetector.submitRequest();
                emotionsDetector.wait();
            }
        }


        int face_idx = 0;

        for (size_t i = 0; i < detections.size(); i++)
        {
            // const auto &detection = detections[i];
            int object_id = detections[i].object_id;

            cv::Scalar label_color = white_color;
            cv::Scalar rect_color = green_color;
            cv::Scalar emo_bar_color;
            std::string label_to_draw = "";

            cv::Rect rect_orig = detections[i].rect_orig;


            if (frame_idx % 3 == 0 && !register_new_person) {
                /* Decide whether truly register this person or not */
                std::size_t found = detections[i].label_txt.find("newp_");
                bool updateLabel = false;
                if (found != std::string::npos)
                { // this person is just registered
                    if (min_dist_by_objectid.find(object_id) == min_dist_by_objectid.end())
                    { // this object_id does not have label yet
                        updateLabel = true;
                    } else { // register but this object_id already have label
                        if (final_label_txt[object_id] == EmbeddingsGallery::unknown_label || final_label_txt[object_id] == "" || final_label_txt[object_id].empty())
                        { // uptill now object_id is still labeled as unknown, so truly register, re-label this object_id
                            updateLabel = true;
                        }
                    }
                } else {
                    /* Compare this recognition with the best recognition in previous frames */
                    if (min_dist_by_objectid.find(object_id) == min_dist_by_objectid.end())
                    { // not found
                        final_label_txt.insert(std::pair<int, std::string>(object_id, detections[i].label_txt));
                        min_dist_by_objectid.insert(std::pair<int, float>(object_id, detections[i].dist));
                    }
                    if (min_dist_by_objectid[object_id] > detections[i].dist)
                    {
                        updateLabel = true;
                    }
                }
                // std::cout<<detections[i].label_txt<<" | "<<detections[i].dist<<" | updateLabel= "<<updateLabel<<std::endl;
                if (updateLabel == true) {
                    final_label_txt[object_id] = detections[i].label_txt;
                    min_dist_by_objectid[object_id] = detections[i].dist;
                }
            }
            // std::cout<<"final_label_txt[object_id]= "<<final_label_txt[object_id]<<std::endl;

            // Draw detection rectangle in blue
            sc_visualizer.DrawRect(rect_orig, brown_color, 1);
            

            Face::Ptr face;
            face = std::make_shared<Face>(object_id, object_id, rect_orig);
            if (frame_idx % 3 == 0 && !register_new_person) {

                face->ageGenderEnable((ageGenderDetector.enabled() &&
                                        i < ageGenderDetector.maxBatch));
                if (face->isAgeGenderEnabled()) {
                    AgeGenderDetection::Result ageGenderResult = ageGenderDetector[i];
                    // face->updateGender(ageGenderResult.maleProb);
                    face->updateAge(ageGenderResult.age);

                    final_age_txt[object_id] = face->getAgeGroup();
                }
                
                face->emotionsEnable((emotionsDetector.enabled() &&
                                        i < emotionsDetector.maxBatch));
                if (face->isEmotionsEnabled()) {
                    face->updateEmotions(emotionsDetector[i]);

                    int final_emo = -1;
                    auto emo_this_frame = face->getMainEmotion().first;
                    if (tot_emos_by_objectid.find(object_id) == tot_emos_by_objectid.end())
                    {
                        tot_emos_by_objectid.insert(std::pair<int, std::vector<float>>(object_id, detections[i].tot_emos));
                    }

                    auto tot_emos = tot_emos_by_objectid[object_id];

                    for (auto k = 0; k < tot_emos.size(); k++)
                    {
                        if (k == emo_this_frame)
                        {
                            tot_emos_by_objectid[object_id][k]++;
                        }
                        tot_emos[i] = tot_emos[i] * weights_emos[i];
                    }

                    final_emo = std::distance(tot_emos.begin(), std::max_element(tot_emos.begin(), tot_emos.end()));
                    final_emo_txt[object_id] = emotionsDetector.emotionsVecTxt[final_emo];

                }
            }


            /* Choose color to draw */
            if (final_label_txt[object_id] == EmbeddingsGallery::unknown_label)
            {
                // Draw in red rectangle and white label
                // label_color = white_color;
                // rect_color = red_color;
                rect_color = brown_color;
            }
            else if (final_label_txt[object_id].find("newp_") != std::string::npos)
            { // this person is newly registered
                label_color = red_color;
                rect_color = white_color;
            }
            else
            {
                // Draw in green rectangle and white label
                label_color = white_color;
                rect_color = dark_green_color;
            }
            emo_bar_color = rect_color;


            /* Draw emotion bar */
            if (!FLAGS_no_show_emotion_bar && tot_emos_by_objectid.find(object_id) != tot_emos_by_objectid.end())
            {
                sc_visualizer.DrawEmotionBar(object_id, face_idx, rect_orig, tot_emos_by_objectid[object_id], tot_emos_by_objectid[object_id], white_color, emo_bar_color);
            }

            /* Draw label and more */
            if (final_label_txt[object_id] != EmbeddingsGallery::unknown_label)
            {
                label_to_draw = final_label_txt[object_id];
            }
            if (!FLAGS_m_ag.empty())
            {
                // if (final_gen_txt.find(object_id) != final_gen_txt.end()) {
                //  label_to_draw += ", " + final_gen_txt[object_id];
                // }
                if (final_age_txt.find(object_id) != final_age_txt.end()) {
                    if (!final_age_txt[object_id].empty() && final_age_txt[object_id] != "") 
                        label_to_draw += " " + final_age_txt[object_id]+"t";
                }
            }
            // Draw bounding box with label
            sc_visualizer.DrawObject(rect_orig, label_to_draw, label_color, 1.85, rect_color, 1, true);
            // Draw emotion label
            if (final_emo_txt.find(object_id) != final_emo_txt.end())
            {
                cv::Scalar emo_label_color = (final_emo_txt[object_id] == EmotionsDetection::emotionsVecTxt[4] || final_emo_txt[object_id] == EmotionsDetection::emotionsVecTxt[2]) ? red_color : (final_emo_txt[object_id] == EmotionsDetection::emotionsVecTxt[1]) ? green_color : blue_color;
                rect_orig.y += 20;
                sc_visualizer.DrawLabel(rect_orig, final_emo_txt[object_id], white_color, 1.85, emo_label_color, true);
            }


            face_idx++;
        }

        auto elapsed = std::chrono::high_resolution_clock::now() - started;
        auto elapsed_ms =
            std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();

        work_time_ms += elapsed_ms;

        ++work_num_frames;

        char k = cv::waitKey(delay);
        if (k == ESC_KEY)
            break;

        sc_visualizer.DrawFPS(1e3f / (work_time_ms / static_cast<float>(work_num_frames) + 1e-6f), blue_color);
        sc_visualizer.frame_idx_ = frame_idx;

        sc_visualizer.Show();
    }

    sc_visualizer.Finalize();

    // close(serial_port);

    if (should_use_perf_counter)
    {
        // face_detector.PrintPerformanceCounts();
        tracker->PrintReidPerformanceCounts(getFullDeviceName(ie, FLAGS_d_reid));
    }
    return 0;
}

int main(int argc, char **argv)
{
    try
    {
        main_work(argc, argv);
    }
    catch (const std::exception &error)
    {
        std::cerr << "[ ERROR ] " << error.what() << std::endl;
        return 1;
    }
    catch (...)
    {
        std::cerr << "[ ERROR ] Unknown/internal exception happened." << std::endl;
        return 1;
    }

    std::cout << "[ INFO ] Execution successful" << std::endl;

    return 0;
}
