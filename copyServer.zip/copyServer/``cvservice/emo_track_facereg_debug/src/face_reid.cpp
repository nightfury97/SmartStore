// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include "face_reid.hpp"
#include "tracker.hpp"
#include "kuhn_munkres.hpp"

#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <limits>

#include <opencv2/opencv.hpp>

namespace
{
float ComputeReidDistance(const cv::Mat &descr1, const cv::Mat &descr2)
{
    float xy = static_cast<float>(descr1.dot(descr2));
    float xx = static_cast<float>(descr1.dot(descr1));
    float yy = static_cast<float>(descr2.dot(descr2));
    float norm = sqrt(xx * yy) + 1e-6f;
    return 1.0f - xy / norm;
}

bool file_exists(const std::string &name)
{
    std::ifstream f(name.c_str());
    return f.good();
}

inline char separator()
{
#ifdef _WIN32
    return '\\';
#else
    return '/';
#endif
}

std::string folder_name(const std::string &path)
{
    size_t found_pos;
    found_pos = path.find_last_of(separator());
    if (found_pos != std::string::npos)
        return path.substr(0, found_pos);
    return std::string(".") + separator();
}

} // namespace

const char EmbeddingsGallery::unknown_label[] = "Unknown";
const int EmbeddingsGallery::unknown_id = TrackedObject::UNKNOWN_LABEL_IDX;

RegistrationStatus EmbeddingsGallery::RegisterIdentity(const std::string &identity_label,
                                                       const cv::Mat &image,
                                                       int min_size_fr, bool crop_face,
                                                       FaceDetection &detector,
                                                       const VectorCNN &landmarks_det,
                                                       const VectorCNN &image_reid,
                                                       std::vector<cv::Mat> &embeddings)
{
    cv::Mat target = image;
    if (crop_face)
    {
        // std::cout<<"Submit to detector..."<<std::endl;
        detector.submitFrame(image, -1);
        detector.waitAndFetchResults();
        // TrackedObjects faces = detector.getResults();
        TrackedObjects faces = detector.results;
        if (faces.size() == 0)
        {
            return RegistrationStatus::FAILURE_NOT_DETECTED;
        }
        // std::cout<<"Start crop..."<<std::endl;
        target = image(faces[0].rect);
    }
    if ((target.rows < min_size_fr) && (target.cols < min_size_fr))
    {
        return RegistrationStatus::FAILURE_LOW_QUALITY;
    }
    // std::cout<<"So far so good"<<std::endl;
    cv::Mat landmarks;
    landmarks_det.Compute(target, &landmarks, cv::Size(2, 5));
    std::vector<cv::Mat> images = {target};
    std::vector<cv::Mat> landmarks_vec = {landmarks};
    AlignFaces(&images, &landmarks_vec);
    image_reid.Compute(images, &embeddings);

    int id = static_cast<int>(identities.size());
    idx_to_id.push_back(id);
    identities.emplace_back(embeddings, identity_label, id);

    std::cout<<"Got here ok"<<std::endl;

    return RegistrationStatus::SUCCESS;
}

RegistrationStatus EmbeddingsGallery::RegisterIdentity(const std::string &identity_label,
                                                       const int &identity_id,
                                                       const std::vector<cv::Mat> &images,
                                                       int min_size_fr, bool crop_gallery,
                                                       FaceDetection &detector,
                                                       const VectorCNN &landmarks_det,
                                                       const VectorCNN &image_reid,
                                                       std::vector<cv::Mat> &embeddings)
{
    std::vector<cv::Mat> targets;
    for (auto &image : images)
    {
        cv::Mat target = image;
        if (crop_gallery)
        {
            detector.submitFrame(image, -1);
            detector.waitAndFetchResults();
            // TrackedObjects faces = detector.getResults();
            TrackedObjects faces = detector.results;
            if (faces.size() == 0)
            {
                return RegistrationStatus::FAILURE_NOT_DETECTED;
            }
            target = (image.clone())(faces[0].rect);
        }
        
        if ((target.rows < min_size_fr) && (target.cols < min_size_fr))
        {
            return RegistrationStatus::FAILURE_LOW_QUALITY;
        }
        else
        {
            targets.push_back(target);
            idx_to_id.push_back(identity_id);
        }
    }
    std::vector<cv::Mat> landmarks;
    landmarks_det.Compute(targets, &landmarks, cv::Size(2, 5));
    AlignFaces(&targets, &landmarks);
    image_reid.Compute(targets, &embeddings);

    return RegistrationStatus::SUCCESS;
}

RegistrationStatus EmbeddingsGallery::RegisterIdentity(const std::string &identity_label, const std::string &template_img_path, const cv::Mat &embedding)
{

    std::vector<cv::Mat> embeddings;
    int id = static_cast<int>(identities.size());

    embeddings.push_back(embedding);
    idx_to_id.push_back(id);
    identities.emplace_back(embeddings, identity_label, id);
    identities_avt_sample.push_back(template_img_path);

    return RegistrationStatus::SUCCESS;
}

EmbeddingsGallery::EmbeddingsGallery(const std::string &ids_list,
                                     double threshold, int min_size_fr,
                                     bool crop_gallery,
                                     FaceDetection &detector,
                                     const VectorCNN &landmarks_det,
                                     const VectorCNN &image_reid)
    : reid_threshold(threshold)
{
    if (ids_list.empty())
    {
        return;
    }

    if (!landmarks_det.Enabled() || !image_reid.Enabled())
    {
        return;
    }

    cv::FileStorage fs(ids_list, cv::FileStorage::Mode::READ);
    cv::FileNode fn = fs.root();
    int id = 0;
    for (cv::FileNodeIterator fit = fn.begin(); fit != fn.end(); ++fit)
    {
        cv::FileNode item = *fit;
        std::string label = item.name();
        std::vector<cv::Mat> embeddings, images;
        CV_Assert(item.size() >= 1);

        std::string path;
        for (size_t i = 0; i < item.size(); i++)
        {

            if (file_exists(item[i].string()))
            {
                path = item[i].string();
            }
            else
            {
                path = folder_name(ids_list) + separator() + item[i].string();
            }

            cv::Mat image = cv::imread(path);
            CV_Assert(!image.empty());
            images.push_back(image);
        }

        std::cout << "Register " << label << " with " << images.size() << " image" << std::endl;

        RegistrationStatus status = RegisterIdentity(label, id, images, min_size_fr, crop_gallery, detector, landmarks_det, image_reid, embeddings);

        if (status == RegistrationStatus::SUCCESS)
        {
            std::cout << "\tSuccess " << std::endl;
            identities_avt_sample.push_back(path);
            identities.emplace_back(embeddings, label, id);
            id++;
        }
        else
        {
            std::cout << "\tError " << std::endl;
        }
    }
}

cv::Mat EmbeddingsGallery::GetTemplateImageByID(int label)
{
    return cv::imread(identities_avt_sample[label]);
}

FacesRecognized EmbeddingsGallery::GetIDsByEmbeddings(const std::vector<cv::Mat> &embeddings) const
{
    if (embeddings.empty() || idx_to_id.empty())
        return std::vector<FaceRecognized>();

    cv::Mat distances(static_cast<int>(embeddings.size()), static_cast<int>(idx_to_id.size()), CV_32F);

    for (int i = 0; i < distances.rows; i++)
    {
        int k = 0;
        for (size_t j = 0; j < identities.size(); j++)
        {
            for (const auto &reference_emb : identities[j].embeddings)
            {
                distances.at<float>(i, k) = ComputeReidDistance(embeddings[i], reference_emb);
                k++;
            }
        }
    }
    KuhnMunkres matcher;
    auto matched_idx = matcher.Solve(distances);

    FacesRecognized faces_recognized;
    for (auto col_idx : matched_idx)
    {
        FaceRecognized face;
        face.dist = distances.at<float>(faces_recognized.size(), col_idx);

        if (distances.at<float>(faces_recognized.size(), col_idx) > reid_threshold)
        {
            face.id = unknown_id;
            faces_recognized.push_back(face);
        }
        else
        {
            face.id = idx_to_id[col_idx];
            faces_recognized.push_back(face);
        }
    }
    return faces_recognized;
}

std::string EmbeddingsGallery::GetLabelByID(int id) const
{
    if (id >= 0 && id < static_cast<int>(identities.size()))
        return identities[id].label;
    else
        return unknown_label;
}

size_t EmbeddingsGallery::size() const
{
    return identities.size();
}

std::vector<std::string> EmbeddingsGallery::GetIDToLabelMap() const
{
    std::vector<std::string> map;
    map.reserve(identities.size());
    for (const auto &item : identities)
    {
        map.emplace_back(item.label);
    }
    return map;
}

bool EmbeddingsGallery::LabelExists(const std::string &label) const
{
    return identities.end() != std::find_if(identities.begin(), identities.end(),
                                            [label](const GalleryObject &o) { return o.label == label; });
}
