// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include <string>
#include <map>
#include <utility>
#include <list>
#include <vector>

#include "face.hpp"

Face::Face(size_t id, int object_id, cv::Rect& location):
    _object_id(object_id),
    _location(location), _intensity_mean(0.f), _id(id), _age(-1),
    _maleScore(0), _femaleScore(0), _headPose({0.f, 0.f, 0.f}),
    _isAgeGenderEnabled(false), _isEmotionsEnabled(false), _isHeadPoseEnabled(false), _isLandmarksEnabled(false),
    _label("") {
}

void Face::updateAge(float value) {
    _age = (_age == -1) ? value : 0.95f * _age + 0.05f * value;
}

void Face::updateGender(float value) {
    if (value < 0)
        return;

    if (value > 0.5) {
        _maleScore += value - 0.5f;
    } else {
        _femaleScore += 0.5f - value;
    }
}

void Face::updateEmotions(std::map<int, float> values) {
    for (auto& kv : values) {
        if (_emotions.find(kv.first) == _emotions.end()) {
            _emotions[kv.first] = kv.second;
        } else {
            _emotions[kv.first] = 0.9f * _emotions[kv.first] + 0.1f * kv.second;
        }
    }
}

void Face::updateHeadPose(HeadPoseDetection::Results values) {
    _headPose = values;
}

void Face::updateLandmarks(std::vector<float> values) {
    _landmarks = std::move(values);
}

void Face::updateLabel(std::string label) {
    _label = label;
}

int Face::getObjectID() {
    return _object_id;
}

std::string Face::getLabel() {
    return _label;
}

int Face::getAge() {
    return static_cast<int>(std::floor(_age + 0.5f));
}

std::string Face::getAgeGroup() {
    std::string age_group;
    // std::cout<<"getAge()="<<getAge()<<std::endl;
    switch (getAge()) {
        case 1 ... 24:
            age_group = "<25";
            break;
        case 25 ... 29:
            age_group = "25-30";
            break;
        case 31 ... 34:
            age_group = "30-35";
            break;
        case 35 ... 39:
            age_group = "35-40";
            break;
        case 40 ... 44:
            age_group = "41-45";
            break;
        case 45 ... 49:
            age_group = "45-50";
            break;
        case 50 ... 59:
            age_group = "50-60";
            break;
        case 60 ... 150:
            age_group = ">=60";
            break;
        default:
            age_group = "";
            break;
    }
    return age_group;
}

bool Face::isMale() {
    return _maleScore > _femaleScore;
}

std::map<int, float> Face::getEmotions() {
    return _emotions;
}

std::pair<int, float> Face::getMainEmotion() {
    auto x = std::max_element(_emotions.begin(), _emotions.end(),
        [](const std::pair<int, float>& p1, const std::pair<int, float>& p2) {
            return p1.second < p2.second; });

    return std::make_pair(x->first, x->second);
}

HeadPoseDetection::Results Face::getHeadPose() {
    return _headPose;
}

const std::vector<float>& Face::getLandmarks() {
    return _landmarks;
}

size_t Face::getId() {
    return _id;
}

void Face::ageGenderEnable(bool value) {
    _isAgeGenderEnabled = value;
}
void Face::emotionsEnable(bool value) {
    _isEmotionsEnabled = value;
}
void Face::headPoseEnable(bool value) {
    _isHeadPoseEnabled = value;
}
void Face::landmarksEnable(bool value) {
    _isLandmarksEnabled = value;
}

bool Face::isAgeGenderEnabled() {
    return _isAgeGenderEnabled;
}
bool Face::isEmotionsEnabled() {
    return _isEmotionsEnabled;
}
bool Face::isHeadPoseEnabled() {
    return _isHeadPoseEnabled;
}
bool Face::isLandmarksEnabled() {
    return _isLandmarksEnabled;
}

float calcIoU(cv::Rect& src, cv::Rect& dst) {
    cv::Rect i = src & dst;
    cv::Rect u = src | dst;

    return static_cast<float>(i.area()) / static_cast<float>(u.area());
}

float calcMean(const cv::Mat& src) {
    cv::Mat tmp;
    cv::cvtColor(src, tmp, cv::COLOR_BGR2GRAY);
    cv::Scalar mean = cv::mean(tmp);

    return static_cast<float>(mean[0]);
}

Face::Ptr matchFace(cv::Rect rect, std::list<Face::Ptr>& faces) {
    Face::Ptr face(nullptr);
    float maxIoU = 0.55f;
    for (auto&& f : faces) {
        float iou = calcIoU(rect, f->_location);
        if (iou > maxIoU) {
            face = f;
            maxIoU = iou;
        }
    }

    return face;
}
