emo_track_facereg_debug \
 -m_det $mFDR16  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16  -m_ag $mAG16 \
 -fg ugly.json \
 -d_det GPU  -d_hp GPU  -d_lm CPU  -d_reid GPU  -d_em GPU  -d_ag GPU \
 -n_em 32  -n_ag 32 \
 -dyn_em  -dyn_hp  -dyn_ag \
 -t_det 0.9  -t_reid 0.45 \
 -min_size_fr 128  -auto_reg  -draw_track \
 -i rtsp://admin:admin123@192.168.1.108:554 \
 -out out/cam




emo_track_facereg_debug \
 -m_det $mFDR16  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16 \
 -fg ugly.json \
 -d_det GPU  -d_hp GPU  -d_lm CPU  -d_reid GPU  -d_em GPU \
 -n_em 32 \
 -dyn_em  -dyn_hp \
 -t_det 0.9  -t_reid 0.45 \
 -min_size_fr 128  -draw_track \
 -i rtsp://admin:admin123@192.168.1.108:554 \
 -out out/cam


 
 
 



emo_track_facereg_debug \
 -m_det $mFDR32  -m_em $mEM32  -m_ag $mAG32  -m_hp $mHP32  -m_lm $mLMR32  -m_reid $mFRI32 \
 -fg ugly.json \
 -d_det GPU  -d_em CPU  -d_ag CPU  -d_hp CPU  -d_lm CPU  -d_reid CPU \
 -t_det 0.9  -t_reid 0.5  -draw_track \
 -min_size_fr 128  -auto_reg \
 -i /dev/video0 \
 -out out/cam




emo_track_facereg_debug \
 -m_det $mFDR32  -m_hp $mHP32  -m_lm $mLMR32  -m_reid $mFRI32 \
 -fg ugly.json \
 -d_det GPU  -d_hp CPU  -d_lm CPU  -d_reid GPU \
 -t_det 0.9  -t_reid 0.5 \
 -min_size_fr 128  -auto_reg \
 -i /dev/video0 \
 -out out/cam







face_reg_track_debug \
 -m_det $mFDR32  -m_reid $mFRI32  -m_lm $mLMR32  -m_hp $mHP32 \
 -fg ugly.json \
 -d_det GPU  -d_reid GPU  -d_lm CPU  -d_hp CPU \
 -t_det 0.9  -t_reid 0.4 \
 -min_size_fr 128 \
 -i rtsp://admin:admin123@192.168.1.108:554






```
emo_track_facereg_debug \
 -m_det $mFDR16  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16  -m_ag $mAG16 \
 -fg ugly.json \
 -d_det GPU  -d_hp GPU  -d_lm CPU  -d_reid GPU  -d_em GPU  -d_ag CPU \
 -n_em 32  -n_ag 32 \
 -dyn_em  -dyn_hp  -dyn_ag \
 -t_det 0.9  -t_reid 0.4 \
 -min_size_fr 128  -draw_track  -auto_reg \
 -i rtsp://admin:admin123@192.168.1.108:554 \
 -out out/cam
```






emo_track_facereg_debug \
 -m_det $mFDR16  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16  -m_ag $mAG16 \
 -fg ugly.json \
 -d_det GPU  -d_hp GPU  -d_lm CPU  -d_reid GPU  -d_em GPU  -d_ag CPU \
 -n_em 32 \
 -dyn_em  -dyn_hp  -dyn_ag \
 -t_det 0.9  -t_reid 0.4 \
 -min_size_fr 128 \
 -i rtsp://admin:admin123@192.168.1.108:554 \
 -out out/cam




emo_track_facereg_debug \
 -m_det $mFDR16  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16 \
 -fg ugly.json \
 -d_det GPU  -d_hp GPU  -d_lm CPU  -d_reid GPU  -d_ag CPU \
 -dyn_em  -dyn_hp  -dyn_ag \
 -t_det 0.9  -t_reid 0.4 \
 -min_size_fr 128 \
 -i rtsp://admin:admin123@192.168.1.108:554 \
 -out out/cam