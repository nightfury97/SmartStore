// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

# pragma once
#include <string>
#include <map>
#include <memory>
#include <utility>
#include <list>
#include <vector>
#include <opencv2/opencv.hpp>

#include "detector.hpp"

// -------------------------Describe detected face on a frame-------------------------------------------------

struct Face {
public:
    using Ptr = std::shared_ptr<Face>;

    explicit Face(size_t id, int object_id, cv::Rect& location);

    void updateAge(float value);
    void updateGender(float value);
    void updateEmotions(std::map<int, float> values);
    void updateHeadPose(HeadPoseDetection::Results values);
    void updateLandmarks(std::vector<float> values);
    void updateLabel(std::string label);

    int getAge();
    std::string getAgeGroup();
    bool isMale();
    std::map<int, float> getEmotions();
    std::pair<int, float> getMainEmotion();

    std::map<int, int> getEmotionsTotal(); // get total frames of each emotion so far
    std::pair<int, int> getMainEmotionSoFar(); // get main emotion so far using softmax
    
    HeadPoseDetection::Results getHeadPose();
    const std::vector<float>& getLandmarks();
    std::string getLabel();
    size_t getId();
    int getObjectID();

    void ageGenderEnable(bool value);
    void emotionsEnable(bool value);
    void headPoseEnable(bool value);
    void landmarksEnable(bool value);

    bool isAgeGenderEnabled();
    bool isEmotionsEnabled();
    bool isHeadPoseEnabled();
    bool isLandmarksEnabled();

public:
    cv::Rect _location;
    float _intensity_mean;

private:
    size_t _id;
    float _age;
    float _maleScore;
    float _femaleScore;
    std::map<int, float> _emotions;
    HeadPoseDetection::Results _headPose;
    std::vector<float> _landmarks;

    int _object_id;
    std::string _label;

    bool _isAgeGenderEnabled;
    bool _isEmotionsEnabled;
    bool _isHeadPoseEnabled;
    bool _isLandmarksEnabled;
};

// ----------------------------------- Utils -----------------------------------------------------------------
float calcIoU(cv::Rect& src, cv::Rect& dst);
float calcMean(const cv::Mat& src);
Face::Ptr matchFace(cv::Rect rect, std::list<Face::Ptr>& faces);
