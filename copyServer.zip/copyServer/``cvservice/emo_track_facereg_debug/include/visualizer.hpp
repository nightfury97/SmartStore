// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#pragma once

#include <memory>
#include <string>
#include <list>
#include <vector>
#include <map>
#include <opencv2/opencv.hpp>

#include "face.hpp"

// -------------------------Generic routines for visualization of detection results-------------------------------------------------

class Visualizer
{
public:
    int frame_idx_ = 0;
    int out_width;
    int out_height;

    explicit Visualizer(bool enabled, cv::VideoWriter &writer, std::vector<std::string> const &emotionNames, std::vector<int> const &emotionCodes, int leftPadding = 10, int rightPadding = 10, int topPadding = 75, int bottomPadding = 10, cv::Size padding = cv::Size(10, 10), cv::Size textSize = cv::Size(300, 10), int textBaseline = 10, int textThickness = 1, double textScale = 0.7, cv::Size emotionBarSize = cv::Size(200, 120));

    void DrawFPS(const float fps, const cv::Scalar &color);
    void DrawRect(cv::Rect rect, const cv::Scalar &bbox_color, int bbox_linewidth);
    void DrawObject(cv::Rect rect, const std::string &label_to_draw,
                    const cv::Scalar &text_color, const double &fontScale, 
                    const cv::Scalar &bbox_color, const int bbox_linewidth,
                    bool plot_bg);
    void DrawLabel(cv::Rect rect, const std::string &label_to_draw,
                   const cv::Scalar &text_color, const double &fontScale, 
                   const cv::Scalar &bbox_color, bool plot_bg, double opacity=1);
    void Show() const;
    void GetCurrentframe(cv::Mat &frame);
    cv::Mat GetCurrentframe();
    void SetFrame(const cv::Mat &frame);
    void SetFrame_orig(const cv::Mat &frame);
    static cv::Size GetOutputSize(const cv::Size &input_size);
    void SetWriter(cv::VideoWriter &writer);
    void Finalize() const;

    void DrawEmotionBar(int object_id, int face_idx, cv::Rect rect, std::vector<float> tot_frames_emos, std::vector<float> prob_frames_emos, cv::Scalar fgcolor, cv::Scalar bgcolor);

private:
    cv::Mat frame_;
    cv::Mat frame_orig_;
    cv::Mat top_persons_;
    const bool enabled_;
    cv::VideoWriter &writer_;
    float rect_scale_x_;
    float rect_scale_y_;
    static int const max_input_width_ = 1920;
    std::string const main_window_name_ = "Face reg track";
    std::string const top_window_name_ = "Top window";
    static int const crop_width_ = 320;
    static int const crop_height_ = 128;
    static int const header_size_ = 80;
    static int const margin_size_ = 5;

    std::vector<std::string> emotionNames;
    std::vector<int> emotionCodes;

    cv::Size padding;
    cv::Size textSize;
    int textBaseline;
    int textThickness;
    double textScale;

    cv::Mat drawMap;
    int nxcells;
    int nycells;
    int xstep;
    int ystep;

    int leftPadding;
    int rightPadding;
    int topPadding;
    int bottomPadding;
    cv::Size emotionBarSize;
    size_t frameCounter;

    // EmotionBarVisualizer::Ptr emotionVisualizer;

    cv::Point findCellForEmotionBar();
};
