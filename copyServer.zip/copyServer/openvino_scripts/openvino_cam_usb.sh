#!/bin/zsh
source ~/.zshrc

cd /home/hiep/Desktop/L/face-access-control-cpp/cvservice/build/intel64/Release/
gnome-terminal --window-with-profile=ExecFromShell -e "./emo_reg_track_multi \
 -m_det $mFDR8  -m_hp $mHP16  -m_lm $mLMR16  -m_reid $mFRI16  -m_em $mEM16  -m_ag $mAG16 \
 -fg /home/hiep/Desktop/L/face-access-control-cpp/good.json \
 -fg_uncheck /home/hiep/Desktop/L/face-access-control-cpp/webservice/server/node-server/public/uncheck \
 -crop_gallery \
 -d_det GPU  -d_hp GPU  -d_lm GPU  -d_reid CPU  -d_em GPU  -d_ag GPU \
 -n_em 32  -n_ag 32  -dyn_ag  -dyn_em \
 -t_det 0.85  -t_reid 0.4 \
 -min_size_fr 128  -draw_track \
 -i /dev/video0 \
 -out out/cam"