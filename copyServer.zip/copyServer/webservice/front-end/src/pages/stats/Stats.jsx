// import React from "react";
import PropTypes from "prop-types";
import Gallery from "react-photo-gallery";
import moment from 'moment';
import Tally from "components/tally/Tally";
import DonutChart from "components/chart-donut/DonutChart";
import ScatterChart from "components/chart-scatter/ScatterChart";
import { CLEARANCE, CLEARANCE_COLORS } from "../../constants/constants";
import UncheckList from "features/uncheck-list/UncheckList";
import UncheckDetails from "features/uncheck-detail/UncheckDetails";
import Button from "components/button/Button";
import SelectedImage from "./SelectedImage";

// import listReactFiles from 'list-react-files';

import "./Stats.css";

// const Stats = ( { logList } ) => {
//   let counts = {
//     A: 0,
//     B: 0,
//     C: 0,
//     D: 0,
//     UNKNOWN: 0,
//   };
//   let visitorsA = [];
//   let visitorsB = [];
//   let visitorsC = [];
//   let visitorsD = [];
//   let visitorsUnknown = [];

//   if ( logList && logList.length > 0 ) {
//     for ( let i = 0; i < logList.length; i += 1 ) {
//       const timeSinceMidnight = moment( logList[ i ].epochTime ).diff( moment().startOf( "day" ) );
//       if ( logList[ i ].clearanceType === "A" ) {
//         counts.A += 1;
//         visitorsA.push( { x: timeSinceMidnight, y: "5" } );
//       } else if ( logList[ i ].clearanceType === "B" ) {
//         counts.B += 1;
//         visitorsB.push( { x: timeSinceMidnight, y: "4" } );
//       } else if ( logList[ i ].clearanceType === "C" ) {
//         counts.C += 1;
//         visitorsC.push( { x: timeSinceMidnight, y: "3" } );
//       } else if ( logList[ i ].clearanceType === "D" ) {
//         counts.D += 1;
//         visitorsD.push( { x: timeSinceMidnight, y: "2" } );
//       } else {
//         counts.UNKNOWN += 1;
//         visitorsUnknown.push( { x: timeSinceMidnight, y: "1" } );
//       }
//     }
//   }

//   const donutData = {
//     labels: [
//       CLEARANCE.A,
//       CLEARANCE.B,
//       CLEARANCE.C,
//       CLEARANCE.D,
//       CLEARANCE.UNKNOWN,
//     ],
//     datasets: [ {
//       data: [ counts.A, counts.B, counts.C, counts.D, counts.UNKNOWN ],
//       backgroundColor: [
//         CLEARANCE_COLORS.A,
//         CLEARANCE_COLORS.B,
//         CLEARANCE_COLORS.C,
//         CLEARANCE_COLORS.D,
//         CLEARANCE_COLORS.UNKNOWN,
//       ],
//       hoverBackgroundColor: [
//         CLEARANCE_COLORS.A_HOVER,
//         CLEARANCE_COLORS.B_HOVER,
//         CLEARANCE_COLORS.C_HOVER,
//         CLEARANCE_COLORS.D_HOVER,
//         CLEARANCE_COLORS.UNKNOWN_HOVER,
//       ],
//     } ],
//   };

//   const scatterData = {
//     labels: [ CLEARANCE.A, CLEARANCE.B, CLEARANCE.C, CLEARANCE.D, CLEARANCE.UNKNOWN ],
//     datasets: [
//       {
//         label: CLEARANCE.A,
//         backgroundColor: CLEARANCE_COLORS.A,
//         pointRadius: 5,
//         data: visitorsA,
//       },
//       {
//         label: CLEARANCE.B,
//         backgroundColor: CLEARANCE_COLORS.B,
//         pointRadius: 5,
//         data: visitorsB,
//       },
//       {
//         label: CLEARANCE.C,
//         backgroundColor: CLEARANCE_COLORS.C,
//         pointRadius: 5,
//         data: visitorsC,
//       },
//       {
//         label: CLEARANCE.D,
//         pointRadius: 5,
//         backgroundColor: CLEARANCE_COLORS.D,
//         data: visitorsD,
//       },
//       {
//         label: CLEARANCE.UNKNOWN,
//         pointRadius: 5,
//         backgroundColor: CLEARANCE_COLORS.UNKNOWN,
//         data: visitorsUnknown,
//       },
//     ],
//   };

//   // Create components
//   let donutComponent = ( <DonutChart graphData={ donutData } graphId="mmmdonut" /> );
//   let scatterComponent = ( <ScatterChart graphData={ scatterData } graphId="scatter" clearance={ CLEARANCE } /> );

//   // If we do not have any data, replace charts with empty states
//   if ( ( counts.A + counts.B + counts.C + counts.D + counts.UNKNOWN ) === 0 ) {
//     donutComponent = ( <p className="chart-empty">No information yet.</p> );
//     scatterComponent = ( <p className="chart-empty">Visitor log not available.</p> );
//   }

//   return (
//     <div className="stats">
//       <Tally counts={ counts } />
//       <div className="chart-row">
//         <div className="chart chart-donut">
//           { donutComponent }
//         </div>
//         <div className="chart chart-scatter">
//           { scatterComponent }
//         </div>
//       </div>
//     </div>
//   );
// };

// Stats.propTypes = {
//   logList: PropTypes.arrayOf( PropTypes.shape( {
//     name: PropTypes.string,
//     clearanceType: PropTypes.string,
//     profileImg: PropTypes.string,
//     epochTime: PropTypes.number.isRequired,
//     time: PropTypes.string.isRequired,
//   } ) ),
// };

// Stats.defaultProps = {
//   logList: [],
// };

import React, { useState, useCallback } from "react";
import { render } from "react-dom";


class Stats extends React.Component {
  constructor( props ) {
    super( props );
    // this.createNewContact = this.createNewContact.bind( this );
    // this.upNewContact = this.upNewContact.bind( this );
    // this.toggleEditMode = this.toggleEditMode.bind( this );
    // this.deleteContact = this.deleteContact.bind( this );
    // this.editContact = this.editContact.bind( this );
    // this.selectContact = this.selectContact.bind( this );
    // this.saveContact = this.saveContact.bind( this );
    // this.cancelAddContact = this.cancelAddContact.bind( this );
    // this.cancelEditContact = this.cancelEditContact.bind( this );
    // this.handleMqtt = this.handleMqtt.bind( this );
    this.selectUncheck = this.selectUncheck.bind( this );
  
    this.toggleSelectAll = this.toggleSelectAll.bind(this);
    this.selectImgArr=this.selectImgArr.bind(this);
    this.confirmImg= this.confirmImg.bind(this);
    this.delUncheck= this.delUncheck.bind(this);
    this.state = {
      uncheckList: [],
      uncheckImageList: [],
      contactList: [],
      currentUncheck: {},
      currentSelect:null,
      currentName: null,
      currentAge: null,
      currentSex: null,
      isLoadingUncheckImage: false,
      imgaa: [],
      imageToUse: '',
      selectAll: false,
      audio: [],
      time:[],
      selectArr: []
    };
  }   

  componentWillMount() {
    this.props.loadAllUnchecks();
    this.props.loadAllContacts();
    // alert(this.state.contactList.length);
  }

  componentDidMount(){

 
  };
  componentWillReceiveProps( nextProps ) {
    
  }

  toggleSelectAll = () => {
    this.setState({selectAll: !this.state.selectAll});
  };


  imageRenderer = (
    ({ index, left, top, key, photo }) => (
      <SelectedImage
        // onClick={this.selectImgArr()}
        selected={this.state.selectAll ? true : false}
        key={key}
        margin={"2px"}
        index={index}
        photo={photo}
        left={left}
        top={top}
        check={this.selectImgArr}
      />
    )
  );

  selectImgArr (imgName) {
    // alert("alo"+imgName);
    if(this.state.selectArr.indexOf(imgName)==-1) {
      this.setState({
        selectArr: [ ...this.state.selectArr, imgName],
      });
    } else {
       let remove = this.state.selectArr.indexOf(imgName);
      //  /alert(imgName);
       this.setState({
         selectArr: this.state.selectArr.filter((_, i) => i !== remove)
       },
      	 () => {
      		console.log('seletArr', this.state.selectArr);
        }
      );
    }
  };

  load(contactUrl){
  
    var name = String(contactUrl);
    fetch( `http://localhost:8000/api/facial-recognition/unchecks/image/${name}` )
    .then( results =>
      {
        return results.json();
      } )
    .then( data =>   
     {
       console.log("lenght: "+data.data.length);
       if(data.data.length==1)
       {
          console.log("lenght 1: "+data.data.length);
          let imagesUncheck = <Gallery          
              photos = {
              data.data.map(img => ({
              src: `http://localhost:8000/api/facial-recognition/file/uncheck%2F${img.image}`,
              height:1,            
              width: 1,
              nameimg: img.image,
              length:1
            }))
          }
          direction={"column"}
          renderImage={this.imageRenderer}
          ></Gallery>
          this.setState({imgaa: imagesUncheck})
       }
       else
       {
          let imagesUncheck = <Gallery          
              photos = {
              data.data.map(img => ({
              src: `http://localhost:8000/api/facial-recognition/file/uncheck%2F${img.image}`,
              height: 2,            
              width: 3,
              nameimg: img.image,
              lenght:data.data.length
            }))
          }
          // direction={"column"}
          renderImage={this.imageRenderer}
          ></Gallery>
        this.setState({imgaa: imagesUncheck})
      }
      })
     };
      
  // componentWillReceiveProps( nextProps ) {
    
  //     this.props.loadUncheckImage(this.state.currentName);
    
  // } 
  selectUncheck( uncheck ) {
      this.setState( { currentUncheck: uncheck,currentName: uncheck.name,currentAge: uncheck.age,currentSex: uncheck.sex } );
      this.load(uncheck.id);
    }

  updateInputValue(evt) {
    alert(evt.target.options[evt.target.selectedIndex].text);
    console.log(evt.target.options[evt.target.selectedIndex].key);
    this.setState({
      imageToUse: `http://localhost:8000/api/facial-recognition/file/profile%2F${evt.target.value}`,
      currentSelect:evt.target.options[evt.target.selectedIndex].text
    });

  }

  confirmImg()
  {
    if(this.state.selectArr.length==0) {alert("Chua chon anh"); return;}
    var body ={
      name: this.state.currentName,
      age: this.state.currentAge,
      sex: this.state.currentSex,      
      uncheck: this.state.currentUncheck,
      img: this.state.selectArr,
      confirm: 1
    }
    fetch( `http://localhost:8000/api/facial-recognition/comfirm`,   { method: "POST", body: JSON.stringify(body) , headers: {  "Content-Type": "application/json"} })
    .then( results =>
      {

        return results.json();
    
      } )
      .then( data =>   
        {
        this.setState( { currentUncheck: null,currentName: "",currentAge: "",currentSex: "" ,imgaa: []} );
          alert("Thành công");
         
        })
  }

  delUncheck()
  {
    var body ={
      name: this.state.currentName,
      age: this.state.currentAge,
      sex: this.state.currentSex,      
      uncheck: this.state.currentUncheck,
      img: this.state.selectArr,
      confirm: 3
    }
    fetch( `http://localhost:8000/api/facial-recognition/comfirm`,   { method: "POST", body: JSON.stringify(body) , headers: {  "Content-Type": "application/json"} })
    .then( results =>
      {
        return results.json();
      } )
      .then( data =>   
        {
          this.setState( { currentUncheck: null,currentName: "",currentAge: "",currentSex: "" ,imgaa: []} );
          alert("Thành công");
          this.props.loadAllUnchecks();
        })
  }
  
  addImg()
  {
    if(this.state.selectArr.length==0) {alert("Chua chon anh"); return;}
    var body ={
      name: this.state.currentSelect,   
      uncheck: this.state.currentUncheck,
      img: this.state.selectArr,
      confirm: 2
    }
    fetch( `http://localhost:8000/api/facial-recognition/comfirm`,   { method: "POST", body: JSON.stringify(body) , headers: {  "Content-Type": "application/json"} })
    .then( results =>
      {
        return results.json();    
      } )
      .then( data =>   
        {
        this.setState( { currentUncheck: null,currentName: "",currentAge: "",currentSex: "" ,imgaa: []} );
          alert("Thành công");         
        })
  }

  render() {
    let bodyClasses = "form-body";
    var divStyle = {
      color: 'black',

      fontSize: '1.4rem',
      paddingTop: '5px',
      paddingLeft: '20px'
    };
    var divStyle12 = {
      backgroundColor:"green",
      paddingRight: '20px'
    };
    var divStyle1 = {
      overflow:scroll,
      color: 'black',
      fontSize: '2.5rem',
    };
    var divStyle2 = {
      color: 'black',
      fontSize: '2.5rem',
    };

    const sortedContacts = this.props.contactList;


    sortedContacts.sort( ( a, b ) => {
      // alert(sortedContacts.length);
      const nameA = a.name.toLowerCase();
      const nameB = b.name.toLowerCase();
      if ( nameA < nameB ) {
        return -1;
      }
      if ( nameA > nameB ) {
        return 1;
      }
      return 0;
    } );
    var uncheck = this.state.currentUncheck;

    let ImagePane=(<UncheckDetails
      uncheck={this.state.currentUncheck}
      imageList={sortedContacts}
      ></UncheckDetails>);
    return(
    <div className="container" >
        <div className="col-2"></div>    
        <UncheckList
          unchecks={this.props.uncheckList}
          forceUpdateHandler = {this.props.forceUpdateHandler}
          selectUncheck={this.selectUncheck}
        ></UncheckList>  
           {/* { ImagePane } */}
         
        <div className="col-4" style={{borderWidth:2}}>
          <h1 style={divStyle2}>Thông tin đối tượng</h1>
          <div className="row">
            <form name="confirmUncheck">
              <div className={bodyClasses}>
                <label htmlFor="name" style={divStyle}>Tên*</label>
                <input type="text" name="name" value={this.state.currentName} 
                    onChange={(event) => {
                      const target = event.target;
                      const value = target.type === "checkbox" ? target.checked : target.value;
                      this.setState({
                          currentName : value
                      })                      
                    }} />
                <label htmlFor="age" style={divStyle}>Tuổi</label>
                <input type="number" name="age" value={this.state.currentAge}  
                onChange={(event) => {
                  const target = event.target;
                  const value = target.type === "checkbox" ? target.checked : target.value;
                  this.setState({
                      currentAge : value
                  })                      
                }}/>
                <label htmlFor="sex" style={divStyle}>Giới tính</label>
                <select name="sex" value={this.state.currentSex} 
                onChange={(event) => {
                  const target = event.target;
                  const value = target.type === "checkbox" ? target.checked : target.value;
                  this.setState({
                      currentSex : value
                  })                      
                }} >
                  <option value="Nam">Nam</option>
                  <option value="Nữ">Nữ</option>
                </select>        
              </div>
              <div className="form-footer" style={divStyle1}>
                <Button label="Xóa" type="button" addClass="btn-cancel" click={this.delUncheck}/>
                <Button label="Duyệt mới" type="button" addClass="btn-save" click={this.confirmImg}/>
                {/* <Button label="Thêm mẫu" type="button" style={divStyle12} addClass="btn-save" click={this.addImg}/> */}
              </div>
            </form>
          </div>
          <div className="row">
              {/* <p>
                <button onClick={this.toggleSelectAll}>select all</button>
              </p> */}
              <p><h1 style={divStyle2}>Danh sách ảnh</h1></p>  
              {this.state.imgaa}
          </div>
        </div>   

        <div style={divStyle2} className="col-4">     
        <h1 style={divStyle2}>Đối tượng có sẵn</h1>       
              <div className={bodyClasses}>
                <label htmlFor="Search" style={divStyle}>Tên*</label>
                {/* <input type="text" list="data" onChange={(evt) => this.updateInputValue(evt)} />
                  <datalist id="data">
                      {sortedContacts.map((item) =>{
                        return (<option key={item.id} value={item.image} data={item.image}>{item.name} </option>)
                      })}
                  </datalist>*/}
                  <select onChange={(evt) => this.updateInputValue(evt)} > 
                  <option disabled selected>Đối tượng có sẵn</option>
                      {sortedContacts.map((item) =>{
                        return (<option key={item.id} value={item.image} data-id={item.image}>{item.name} </option>)
                      })}
                  </select>
              </div>
              <div className="form-footer" style={divStyle1}>
              <img src={ this.state.imageToUse } id="campic" />
              </div>           
        </div>
    </div>
    )
  };
}

Stats.propTypes = {
  // this provides route info, will cause lint error
  loadAllContacts: PropTypes.func.isRequired,
  loadUncheckImage: PropTypes.func.isRequired,
  loadAllUnchecks: PropTypes.func.isRequired,
  match: PropTypes.object,
  contactList: PropTypes.array,
  uncheckList: PropTypes.array,
  audio: PropTypes.array,
  uncheckImageList: PropTypes.array,
  currentUncheck: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
    sex: PropTypes.string.isRequired
  }).isRequired,
  selectAll: PropTypes.bool.isRequired,
  toggleSelectAll: PropTypes.func.isRequired,
  selectArr:  PropTypes.array,
};

Stats.defaultProps = {
  match: {},
  uncheckList: [],
  contactList: [],
  uncheckImageList: [],
  audio: [],
  selectArr: []
};



export default Stats;
