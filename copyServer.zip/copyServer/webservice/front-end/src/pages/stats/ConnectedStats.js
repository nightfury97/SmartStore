import { connect } from "react-redux";
import { push } from "react-router-redux";
import { loadAllUnchecks,loadAllContacts,loadUncheckImage} from "dux/directory";
import Stats from "./Stats";

// maps the redux state to this components props
const mapStateToProps = state => ( {
  logList: state.profile.logList,
  uncheckList: state.directory.uncheckList,
  uncheckImageList: state.directory.uncheckImageList,
  contactList: state.directory.contactList,
  currentName: state.directory.currentName,
  isLoadingUncheckImage: state.directory.isLoadingUncheckImage

} );

const mapDispatchToProps = dispatch => ( {
  loadUncheckImage: ( name ) => {

    // alert("chay vao name:"+name);
    dispatch( loadUncheckImage( name ) );
    // console.log("name :" + dispatch.uncheckImageList);
  },
  loadAllUnchecks: () => {

    dispatch( loadAllUnchecks() );
  },
  loadAllContacts: () => {
    dispatch( loadAllContacts() );
  },
} );

export default connect( mapStateToProps,mapDispatchToProps )( Stats );
