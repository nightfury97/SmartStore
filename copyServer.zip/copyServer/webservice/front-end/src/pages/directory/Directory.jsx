import React from "react";
import PropTypes from "prop-types";
import ContactDetails from "features/contact-details/ContactDetails";
import ContactAdd from "features/contact-add/ContactAdd";
import ContactEdit from "features/contact-edit/ContactEdit";
import ContactList from "features/contact-list/ContactList";
import ContactUp from "features/contact-upload/App";
import mq from "../../MqttClient";
import { SETTINGS, MQTT } from "../../constants/constants";
import "./Directory.css";

class Directory extends React.Component {
  constructor( props ) {
    super( props );
    this.createNewContact = this.createNewContact.bind( this );
    this.upNewContact = this.upNewContact.bind( this );
    this.toggleEditMode = this.toggleEditMode.bind( this );
    this.deleteContact = this.deleteContact.bind( this );
    this.editContact = this.editContact.bind( this );
    this.selectContact = this.selectContact.bind( this );
    this.saveContact = this.saveContact.bind( this );
    this.cancelAddContact = this.cancelAddContact.bind( this );
    this.cancelEditContact = this.cancelEditContact.bind( this );
    this.handleMqtt = this.handleMqtt.bind( this );

    this.state = {
      viewMode: "view",
      editedValues: [],
      currentContact: {},
      currentContactId: null,
      currentPersonReturned: null,
      contactList: [],
    };
  }

  componentWillMount() {
    this.props.loadAllContacts();
  
  }

  componentDidMount() {
    // register handler with mqtt client
    mq.addHandler( "register", this.handleMqtt );
  }
  componentWillUnmount() {
    mq.removeHandler( "register" );
  }

  componentWillReceiveProps( nextProps ) {
    if ( this.props.isAddingNewPerson && !nextProps.isAddingNewPerson ) {
      this.props.loadAllContacts();
    }
  } 

  upNewContact() {
    this.setState( { viewMode: "up" } );
    // mq.publish( MQTT.TOPICS.REGISTER );
  }

  createNewContact() {
    this.setState( { viewMode: "add" } );
    mq.publish( MQTT.TOPICS.REGISTER );
  }
  toggleEditMode() {
    this.setState( { viewMode: "edit" } );
  }

  deleteContact( eventData ) {
    //this.setState( { viewMode: "delete" } );
    if(confirm("Do you want to delete this person?") == true){
      event.preventDefault();
      event.stopPropagation();
      alert(eventData);
      this.props.deleteContact(parseInt(eventData));
      this.props.loadAllContacts();
      this.setState( { viewMode: "view", currentContact: {} } );
    }
  }

  selectContact( contact ) {
    alert(this.props.contactList.length); 
    this.setState( { currentContact: contact } );
  }

  cancelAddContact() {
    this.setState( { viewMode: "view", currentContactId: null } );
  }

  cancelEditContact() {
    this.setState( { viewMode: "view" } );
  }
  // not currently used
  handleMqtt( topic, payload ) {
    switch ( topic ) {
      case MQTT.TOPICS.REGISTERED:
        this.props.personRegistered( payload.id );
        break;
      default:
        break;
    }
  }
  saveContact( eventData ) {
    event.preventDefault();
    event.stopPropagation();
    const newPerson = { profile: {
      id: this.props.returnedPerson,
      name: eventData.name,
      clearanceType: eventData.clearanceType,
      position: eventData.position,
      age: eventData.age,
      height: eventData.height,
      weight: eventData.weight,
      phone: eventData.phone,
      email: eventData.email,
    } };
    this.props.saveNewContact( newPerson );
    mq.publish( MQTT.TOPICS.NAME,eventData.name );

    this.setState( { viewMode: "view", currentContactId: null } );
  }

  editContact( eventData ) {
    event.preventDefault();
    event.stopPropagation();
    const person = { profile: {
      id: eventData.id,
      name: eventData.name,
      clearanceType: eventData.clearanceType,
      position: eventData.position,
      age: eventData.age,
      height: eventData.height,
      weight: eventData.weight,
      phone: eventData.phone,
      email: eventData.email,
    } };
    this.props.editContact( person );
    this.setState( { viewMode: "view", currentContactId: person.id } );
  }

  render() {
    const sortedContacts = this.props.contactList;

    sortedContacts.sort( ( a, b ) => {
      const nameA = a.name.toLowerCase();
      const nameB = b.name.toLowerCase();
      if ( nameA < nameB ) {
        return -1;
      }
      if ( nameA > nameB ) {
        return 1;
      }
      return 0;
    } );

    let contactPane = ( <ContactDetails
      profile={ this.state.currentContact }
      currentId={ this.state.currentContact.id }
      toggleEditMode={ this.toggleEditMode }
      deleteContact={this.deleteContact}
      viewMode={ this.state.viewMode }
    /> );

    if ( this.state.viewMode === "edit" ) {
      contactPane = ( <ContactEdit
        profile={ this.state.currentContact }
        currentId={ this.state.currentContact.id }
        editContact = { this.editContact }
        cancelEditContact = {this.cancelEditContact}
        viewMode={ this.state.viewMode }
      /> );
    }

    if ( this.state.viewMode === "add" ) {
      contactPane = ( <ContactAdd
        returnedPerson={ this.props.returnedPerson }
        haveRegisteredPerson={ this.props.haveRegisteredPerson }
        saveContact={ this.saveContact }
        cancelAddContact={ this.cancelAddContact }
        viewMode={ this.state.viewMode }
      /> );
    }
    if ( this.state.viewMode === "up" ) {
      contactPane = ( <ContactUp
        // uploadImage={this.props.uploadImage}
      /> );
    }

    return (
      <div className="page-directory">
        { contactPane }

        <ContactList
          contacts={ sortedContacts }
          selectContact={ this.selectContact }
          createNewContact={ this.createNewContact }
          upNewContact = {this.upNewContact}
          viewMode={ this.state.viewMode }
        />
      </div>
    );
  }
}

Directory.propTypes = {
  // this provides route info, will cause lint error
  match: PropTypes.object,
  loadAllContacts: PropTypes.func.isRequired,
  saveNewContact: PropTypes.func.isRequired,
  contactList: PropTypes.array,
  haveRegisteredPerson: PropTypes.bool.isRequired,
  returnedPerson: PropTypes.string,
  personRegistered: PropTypes.func.isRequired,
  isAddingNewPerson: PropTypes.bool.isRequired,
};

Directory.defaultProps = {
  match: {},
  contactList: [],
  returnedPerson: null,
};

export default Directory;
