import { HTTP } from "constants/constants";

// actions
const CONTACT_LOAD_REQUEST = "pages/directory/CONTACT_LOAD_REQUEST";
const CONTACT_LOADED = "pages/directory/CONTACT_LOADED";
const CONTACT_ERROR = "pages/directory/CONTACT_ERROR";

const CONTACT_ALL_LOAD_REQUEST = "pages/directory/CONTACT_ALL_LOAD_REQUEST";
const CONTACT_ALL_LOADED = "pages/directory/CONTACT_ALL_LOADED";
const CONTACT_ALL_ERROR = "pages/directory/CONTACT_ALL_ERROR";

const UNCHECK_LOAD_REQUEST = "pages/directory/UNCHECK_LOAD_REQUEST";
const UNCHECK_LOADED = "pages/directory/UNCHECK_LOADED";
const UNCHECK_ERROR = "pages/directory/UNCHECK_ERROR";

const UNCHECK_ALL_LOAD_REQUEST = "pages/directory/UNCHECK_ALL_LOAD_REQUEST";
const UNCHECK_ALL_LOADED = "pages/directory/UNCHECK_ALL_LOADED";
const UNCHECK_ALL_ERROR = "pages/directory/UNCHECK_ALL_ERROR";

const UNCHECKIMAGE_LOAD_REQUEST = "pages/directory/UNCHECK_LOAD_REQUEST";
const UNCHECKIMAGE_LOADED = "pages/directory/UNCHECK_LOADED";
const UNCHECKIMAGE_ERROR = "pages/directory/UNCHECK_ERROR";

const MONITOR_START_REQUEST = "pages/directory/MONITOR_START_REQUEST";
const MONITOR_START_SUCCEED = "pages/directory/MONITOR_START_SUCCEED";
const MONITOR_START_ERROR = "pages/directory/MONITOR_START_ERROR";

const MONITOR_STOP_REQUEST = "pages/directory/MONITOR_STOP_REQUEST";
const MONITOR_STOP_SUCCEED = "pages/directory/MONITOR_STOP_SUCCEED";
const MONITOR_STOP_ERROR = "pages/directory/MONITOR_STOP_ERROR";

const SAVE_NEW_REQUEST = "pages/directory/SAVE_NEW_REQUEST";
const SAVE_NEW_SUCCEEDED = "pages/directory/SAVE_NEW_SUCCEEDED";
const SAVE_NEW_ERROR = "pages/directory/SAVE_NEW_ERROR";

const DELETE_CONTACT_REQUEST = "pages/directory/DELETE_CONTACT_REQUEST";
const DELETE_CONTACT_SUCCEEDED = "pages/directory/DELETE_CONTACT_SUCCEEDED";
const DELETE_CONTACT_ERROR = "pages/directory/DELETE_CONTACT_ERROR";

const EDIT_CONTACT_REQUEST = "pages/directory/EDIT_CONTACT_REQUEST";
const EDIT_CONTACT_SUCCEEDED = "pages/directory/EDIT_CONTACT_SUCCEEDED";
const EDIT_CONTACT_ERROR = "pages/directory/EDIT_CONTACT_ERROR";

const PERSON_REGISTERED = "pages/directory/PERSON_REGISTERED";
const PERSON_DELETED = "pages/directory/PERSON_DELETED";


// initial state
const initialState = {
  currentId: null,
  contactList: [],
  uncheckList: [],
  uncheckImageList: [],
  newProfile: {},
  saveStatus: "",
  deleteStatus: "",
  editStatus: "",
  error: null,
  isFetchingContact: false,
  isLoadingUncheckImage: false,
  isFetchingUncheck: false,
  isFetchingUncheckImage: false,
  isFetchingAllContact: false,
  isFetchingAllUncheck: false,
  isAddingNewPerson: false,
  isDeletingPerson: false,
  isEditingPerson: false,
  isMonitorFetch: false,
  returnedPerson: undefined,
  haveRegisteredPerson: false,
  haveDeletedPerson: false,
};

// reducer
export default function reducer( state = initialState, action = {} ) {
  switch ( action.type ) {
    // Load single contact
    case CONTACT_LOAD_REQUEST:
      return {
        ...state,
        isFetchingContact: action.isFetchingContact,
      };
    case CONTACT_LOADED:
      return {
        ...state,
        isFetchingContact: action.isFetchingContact,
        currentId: action.currentId,
      };
    case CONTACT_ERROR:
      return {
        ...state,
        isFetchingContact: action.isFetchingContact,
      };
    
    // Load all contacts
    case CONTACT_ALL_LOAD_REQUEST:
      return {
        ...state,
        isFetchingAllContact: action.isFetchingAllContact,
      };
    case CONTACT_ALL_LOADED: 
      return {
        ...state,
        isFetchingAllContact: action.isFetchingAllContact,
        contactList: action.contactList,
      };
    case CONTACT_ALL_ERROR:
      return {
        ...state,
        isFetchingAllContact: action.isFetchingAllContact,
      };
    
    case UNCHECK_LOAD_REQUEST:
      return {
        ...state,
        isFetchingUncheck: action.isFetchingUncheck,
      };
    case UNCHECK_LOADED:
      return {
        ...state,
        isFetchingUncheck: action.isFetchingUncheck,
        currentId: action.currentId,
      };
    case UNCHECK_ERROR:
      return {
        ...state,
        isFetchingContact: action.isFetchingUncheck,
      };  

    case UNCHECKIMAGE_LOAD_REQUEST:
      return {
        ...state,
        isFetchingUncheckImage: action.isFetchingUncheckImage,
      };
    case UNCHECKIMAGE_LOADED:
      return {
        ...state,
        isFetchingUncheckImage: action.isFetchingUncheckImage,
        uncheckImageList: action.uncheckImageList,
        
      };
    case UNCHECKIMAGE_ERROR:
      return {
        ...state,
        isFetchingUncheckImage: action.isFetchingUncheckImage,
      };  

    case UNCHECK_ALL_LOAD_REQUEST:
      return {
        ...state,
        isFetchingAllUncheck: action.isFetchingAllUncheck,
      };
    case UNCHECK_ALL_LOADED: 
      return {
        ...state,
        isFetchingAllUncheck: action.isFetchingAllUncheck,
        uncheckList: action.uncheckList,
      };
    case UNCHECK_ALL_ERROR:
      return {
        ...state,
        isFetchingAllUncheck: action.isFetchingAllUncheck,
      };
    // Save new contact
    case SAVE_NEW_REQUEST:
      return {
        ...state,
        isAddingNewPerson: action.isAddingNewPerson,
      };
    case SAVE_NEW_SUCCEEDED: 
      return {
        ...state,
        isAddingNewPerson: action.isAddingNewPerson,
      };
    case SAVE_NEW_ERROR:
      return {
        ...state,
        isAddingNewPerson: action.isAddingNewPerson,
      };
    case PERSON_REGISTERED:
      return {
        ...state,
        returnedPerson: action.returnedPerson,
        haveRegisteredPerson: action.haveRegisteredPerson,
      };

      // delete contact
    case DELETE_CONTACT_REQUEST:
      return {
        ...state,
        isDeletingPerson: action.isDeletingPerson,
      };
    case DELETE_CONTACT_SUCCEEDED: 
      return {
        ...state,
        isDeletingPerson: action.isDeletingPerson,
      };
    case DELETE_CONTACT_ERROR:
      return {
        ...state,
        isDeletingPerson: action.isDeletingPerson,
      };
    case PERSON_DELETED:
      return {
        ...state,
        haveDeletedPerson: action.haveDeletedPerson,
      };

        // edit contact
    case EDIT_CONTACT_REQUEST:
      return {
        ...state,
        isEditingPerson: action.isEditingPerson,
      };
    case EDIT_CONTACT_SUCCEEDED: 
      return {
        ...state,
        isEditingPerson: action.isEditingPerson,
      };
    case EDIT_CONTACT_ERROR:
      return {
        ...state,
        isEditingPerson: action.isEditingPerson,
      };

    default: return state;
  }
}
function startTime(){
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds(); 
  return [ h, m, s ].join(':')
}
// syncronous (instant) action creators

// ------ http request related actions ------ //

// ------ LOAD SINGLE RECORD ------ //
// initialize loading state
function startContactLoad() {
  return {
    type: CONTACT_LOAD_REQUEST,
    isFetchingContact: true,
  };
}

// load completed
function contactLoaded( json ) {
  return {
    type: CONTACT_LOADED,
    isFetchingContact: false,
    currentId: "123", // json.data.id
  };
}

// loading error
function contactAllError( error ) {
  return {
    type: CONTACT_ALL_ERROR,
    isFetchingContact: false,
    error,
  };
}
// initialize loading state
function startUncheckLoad() {
  return {
    type: UNCHECK_LOAD_REQUEST,
    isFetchingUncheck: true,
  };
}

// load completed
function uncheckLoaded( json ) {
  return {
    type: UNCHECK_LOADED,
    isFetchingUncheck: false,
    currentId: "123", // json.data.id
  };
}

// loading error
function uncheckAllError( error ) {
  return {
    type: UNCHECK_ALL_ERROR,
    isFetchingUncheck: false,
    error,
  };
}

// initialize loading state
function startUncheckImageLoad() {
  // alert("co chay vao ham start image"+ " datetime"+ startTime());
  initialState.isLoadingUncheckImage=true;
  return {
    type: UNCHECKIMAGE_LOAD_REQUEST,
    isFetchingUncheckImage: true,
    isLoadingUncheckImage: true,
  };
}

// load completed
function uncheckImageLoaded( json ) {
  // alert("co chay vao ham load image"+ " datetime"+ startTime());
  initialState.isLoadingUncheckImage=false;
  initialState.uncheckImageList=json.data;
  return {
    type: UNCHECKIMAGE_LOADED,
    isFetchingUncheckImage: false,
    uncheckImageList: json.data,
    isLoadingUncheckImage: false,
  };
}

// loading error
function uncheckImageError( error ) {
  return {
    type: UNCHECKIMAGE_ERROR,
    isFetchingUncheckImage: false,
    error,
  };
}


// ------ LOAD ALL RECORDS ------ //
// initialize loading state
function startContactAllLoad() {
  return {
    type: CONTACT_ALL_LOAD_REQUEST,
    isFetchingAllContact: true,
  };
}

// load completed
function contactAllLoaded( json ) {
  return {
    type: CONTACT_ALL_LOADED,
    isFetchingAllContact: false,
    contactList: json.data,
  };
}

// loading error
function contactAllError( error ) {
  return {
    type: CONTACT_ALL_ERROR,
    isFetchingAllContact: false,
    error,
  };
}
function startUncheckAllLoad() {
  return {
    type: UNCHECK_ALL_LOAD_REQUEST,
    isFetchingAllUncheck: true,
  };
}
// load uncheck completed
function uncheckAllLoaded( json ) {
  return {
    type: UNCHECK_ALL_LOADED,
    isFetchingAllUncheck: false,
    uncheckList: json.data,
  };
}

// loading error
function uncheckAllError( error ) {
  return {
    type: UNCHECK_ALL_ERROR,
    isFetchingAllUncheck: false,
    error,
  };
}
// ------ START MONITOR ------ //
// initialize monitor
function startMonitorBegin() {
  return {
    type: MONITOR_START_REQUEST,
    isMonitorFetch: true,
  };
}

// monitor start
function startMonitorSucceed( json ) {
  return {
    type: MONITOR_START_SUCCEED,
    isMonitorFetch: false,
    returnedPerson: json.data,
  };
}

// monitor start failure
function startMonitorError( error ) {
  return {
    type: MONITOR_START_ERROR,
    isMonitorFetch: false,
    error,
  };
}

// ------ STOP MONITOR ------ //
// initialize loading state
function stopMonitorBegin() {
  return {
    type: MONITOR_STOP_REQUEST,
    isMonitorFetch: true,
  };
}

// load completed
function stopMonitorSucceed() {
  return {
    type: MONITOR_STOP_SUCCEED,
    isMonitorFetch: false,
    returnedPerson: null,
  };
}

// loading error
function stopMonitorError( error ) {
  return {
    type: MONITOR_STOP_ERROR,
    isMonitorFetch: false,
    error,
  };
}

// ------ SAVE NEW RECORD ------ //
// initialize loading state
function startSaveNew() {
  return {
    type: SAVE_NEW_REQUEST,
    isAddingNewPerson: true,
  };
}

// load completed
function saveNewSucceeded( json ) {
  if (json.status === "success") {
    return {
      type: SAVE_NEW_SUCCEEDED,
      isAddingNewPerson: false,
      currentId: json.data.id,
      saveStatus: "saved",
      returnedPerson: undefined,
      haveRegisteredPerson: false,
    };
  } else return{
    type: SAVE_NEW_ERROR,
    isAddingNewPerson: false,
    error: json.errors,
  }
}

// loading error
function saveNewError( error ) {
  return {
    type: SAVE_NEW_ERROR,
    isAddingNewPerson: false,
    error,
  };
}

// load completed
export function personRegistered( id ) {
  return {
    type: PERSON_REGISTERED,
    returnedPerson: id,
    haveRegisteredPerson: true,
  };
}

// ----DELETE PERSION--
function startDeleteContact(){
  return {
    type: DELETE_CONTACT_REQUEST,
    isDeletingPerson: true
  }
}

function deleteSuccess(json){
  if (json.status === "success") {
    return {
      type: DELETE_CONTACT_SUCCEEDED,
      isDeletingPerson: false,
      deleteStatus: "deleted",
      haveDeletedPerson: false,
    };
  } else return{
    type: DELETE_CONTACT_ERROR,
    isDeletingPerson: false,
    error: json.errors,
  }
}

function deleteError( error ) {
  return {
    type: DELETE_CONTACT_ERROR,
    isDeletingPerson: false,
    error,
  };
}

// load completed
export function personDeleted( id ) {
  return {
    type: PERSON_DELETED,
    //returnedPerson: id,
    haveDeletedPerson: true,
  };
}

// ----EDIT PERSION--
function startEditContact(){
  return {
    type: EDIT_CONTACT_REQUEST,
    isEditingPerson: true
  }
}

function editSuccess(json){
  if (json.status === "success") {
    return {
      type: EDIT_CONTACT_SUCCEEDED,
      isEditingPerson: false,
      editStatus: "deleted",
    };
  } else return{
    type: EDIT_CONTACT_ERROR,
    isEditingPerson: false,
    error: json.errors,
  }
}

function editError( error ) {
  return {
    type: EDIT_CONTACT_ERROR,
    isEditingPerson: false,
    error,
  };
}

// asyncronous action creator
export function loadContact(contactID) {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startContactLoad() );
    // load the data
    let contactUrl = HTTP.DATA_SINGLE_CONTACT += contactId; 
    return fetch( contactUrl )
      .then( response => response.json() )
      .then( json =>
        // dispatched loaded data
        dispatch( contactLoaded( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( contactError( error ) ),
      );
  };
}

export function loadAllContacts() {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startContactAllLoad() );
    // load the data
    let contactUrl = HTTP.DATA_ALL_CONTACTS; 
    return fetch( contactUrl )
      .then( response => response.json() )
      .then( json =>
        // dispatched loaded data
        dispatch( contactAllLoaded( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( contactAllError( error ) ),
      );
  };
}

export function startMonitoring() {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startMonitorBegin() );
    // send the data
    let watchTopic = MQTT.REGISTERED; 
    return fetch( watchTopic )
      .then( response => response.json() )
      .then( 
        json =>
        // dispatched loaded data
        dispatch( startMonitorSucceed( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( startMonitorError( error ) ),
      );
  };
}

export function stopMonitoring() {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( stopMonitorBegin() );
    // send the data
    let watchTopic = MQTT.REGISTERED; 
    return fetch( watchTopic )
      .then( response => response.json() )
      .then( 
        json =>
        // dispatched loaded data
        dispatch( stopMonitorSucceed( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( stopMonitorError( error ) ),
      );
  };
}


export function saveNewContact( newPerson ) {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startSaveNew() );
    // send the data
    let contactUrl = HTTP.DATA_INSERT_PROFILE; 
    return fetch( contactUrl, { method: "POST", body: JSON.stringify(newPerson), headers: { "Content-Type": "application/json" } } )
      .then( response => response.json() )
      .then( 
        json =>
        // dispatched loaded data
        dispatch( saveNewSucceeded( json ) )
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( saveNewError( error ) ),
      );
  };
}

export function deleteContact( id ) {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startDeleteContact() );
    // send the data
    let contactUrl = HTTP.DATA_DELETE_PROFILE += id; 
    alert(contactUrl);
    return fetch( contactUrl, { method: "DELETE"} )
      .then( response => response.json() )
      .then( 
        json =>
        // dispatched loaded data
        dispatch( deleteSuccess( json ) )
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( deleteError( error ) ),
      );
  };
}

export function editContact( person ) {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startEditContact() );
    // send the data
    let contactUrl = HTTP.DATA_EDIT_PROFILE; 
    return fetch( contactUrl, { method: "PUT", body: JSON.stringify(person), headers: { "Content-Type": "application/json" } } )
      .then( response => response.json() )
      .then( 
        json =>
        // dispatched loaded data
        dispatch( editSuccess( json ) )
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( editError( error ) ),
      );
  };
}

export function loadUncheck(contactID) {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startUncheckLoad() );
    // load the data
    let contactUrl = HTTP.DATA_SINGLE_UNCHECK += contactId; 
    return fetch( contactUrl )
      .then( response => response.json() )
      .then( json =>
        // dispatched loaded data
        dispatch( uncheckLoaded( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( UncheckError( error ) ),
      );
  };
}

export function loadAllUnchecks() {
  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startUncheckAllLoad() );
    // load the data
    let contactUrl = HTTP.DATA_ALL_UNCHECK; 
    return fetch( contactUrl )
      .then( response => response.json() )
      .then( json =>
        // dispatched loaded data
        dispatch( uncheckAllLoaded( json ) ),
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( uncheckAllError( error ) ),
      );
  };
}
export function loadUncheckImage(name) {

  return ( dispatch ) => {
    // dispatch to start a spinner or to disable mouse actions
    dispatch( startUncheckImageLoad() );
    // alert("vao uncheck: "+name+" stt "+initialState.isLoadingUncheckImage+ " datetime"+ startTime()); 
    
    // load the data
    let contactUrl = HTTP.GET_UNCHECK_IMAGE + name; 
    alert("url "+ contactUrl+ " datetime"+ startTime());
    return fetch( contactUrl )
      .then( response => response.json() )
      .then( json =>
        // dispatched loaded data
        dispatch( uncheckImageLoaded( json ) ),
        console.log("checkpoint: "+contactUrl+" list" +initialState.uncheckImageList )
      )
      .catch( error =>
        // dispatched an http error occurred
        dispatch( uncheckImageError( error ) ),
      );
  };
}