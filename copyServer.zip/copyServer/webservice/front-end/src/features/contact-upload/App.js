import React, {Component} from "react";
import {
    Card, CardHeader, CardBody,
    FormGroup, Label, Input,
    Form, Row, Col, Select
} from 'reactstrap';
import axios, {post, get} from 'axios';
import Progress from './Progress';
import './App.css';

function bodauTiengViet(str) {
    // str = str.toLowerCase();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ấ|Ầ|Ậ|Ẫ|Ẩ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ế|Ề|Ệ|Ể|Ễ/g, 'E');
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
    str = str.replace(/Ì|Í|Ị|ỉ|Ỉ|ĩ/g, 'I');
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ố|Ồ|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'y');
    str = str.replace(/đ/g, 'd');
    str = str.replace(/Đ/g, 'D');
    // str = str.replace(/\W+/g, ' ');
    str = str.replace(/\s/g, '_');
    return str;
}

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            file: null,
            name: "",
            age:"",
            sex:"",
            personName: "",
            uploadPercentage: 0
        }
      
    }
   
    render() {
        return (
            <div className="container" style={{paddingTop: 30}}>
                <Row>
                    <Col sm={12}>
                        <Card>
                            <CardHeader>
                                THÊM ĐỐI TƯỢNG
                            </CardHeader>
                            <CardBody>
                                <Row>
                                    <Col sm={12}>
                                        <Form
                                            encType="multipart/form-data"
                                        >
                                            <FormGroup>
                                                <Label for="avatar">Chọn ảnh</Label>
                                                <Input
                                                    onChange={(evt) => {
                                                        evt.preventDefault();
                                                        this.setState({
                                                            file: evt.target.files,
                                                            
                                                        })
                                                    }}
                                                    multiple
                                                    type="file" name="avatar" id="avatar"
                                                    placeholder="chọn file"/>
                                                <Label for="name">Nhập tên</Label>
                                                <Input
                                                    onChange={(event) => {
                                                        const target = event.target;
                                                        const value = target.type === "checkbox" ? target.checked : target.value;
                                                        this.setState({
                                                            personName : value,
                                                            name : value
                                                        })
                                                        
                                                    }}
                                                    type="text" name="name" id="name"
                                                    placeholder="Nhập tên"/>
                                                <Label for="name">Nhập tuổi</Label>                                               
                                                <Input
                                                    onChange={(event) => {
                                                        const target = event.target;
                                                        const value = target.type === "checkbox" ? target.checked : target.value;
                                                        this.setState({
                                                            age : value
                                                        })
                                                        
                                                    }}

                                                    type="number" name="age" id="age" min={0} max={100} step="1"
                                                    placeholder="Nhập tuổi"/>
                                                <Label for="name">Nhập giới tính</Label>                                                
                                                <Input
                                                    onChange={(event) => {
                                                        const target = event.target;
                                                        const value = target.type === "checkbox" ? target.checked : target.value;
                                                        this.setState({
                                                            sex : value
                                                        })
                                                        
                                                    }}
                                                    type="select" name="sex" id="sex">
                                                        <option defaultValue value="Nam">Nam</option>
                                                        <option value="Nữ">Nữ</option>
                                                </Input>
                                                       
                                            </FormGroup>
                                            <button
                                                className="btn btn-primary"
                                                onClick={(evt) => {
                                                    evt.preventDefault()
                                                    if (!this.state.file) {
                                                        alert('Bạn chưa chọn file.')
                                                        return;
                                                    }
                                                    if (!this.state.name)
                                                    {
                                                        alert('Bạn chưa nhập tên.')
                                                        return;
                                                    }
                                                    const types = ['image/png', 'image/jpeg']
                                                    const formData = new FormData();
                                                    for(var x = 0; x<this.state.file.length; x++) {
                                                        formData.append('avatar', this.state.file[x],bodauTiengViet(this.state.personName))
                                                    }
                                                    formData.append("name", this.state.name);
                                                    if (this.state.age)
                                                    {
                                                        formData.append("age", this.state.age);
                                                    }
                                                    else
                                                    {
                                                        formData.append("age", 0);
                                                    }
                                                    if (this.state.sex)
                                                    {
                                                        formData.append("sex", this.state.sex);
                                                    }
                                                    else
                                                    {
                                                        formData.append("sex", "nam");
                                                    }
                                                   
                                                    const config = {
                                                        headers: {
                                                            'content-type': 'multipart/form-data'
                                                        },
                                                        onUploadProgress: progressEvent => {
                                                            this.setState({
                                                                uploadPercentage:   parseInt(Math.round((progressEvent.loaded * 100) / progressEvent.total))
                                                            });
                                                        setTimeout(() => this.setState({ uploadPercentage:  0 }), 10000);
                                                        }
                                                    }
                                                    post('http://localhost:8082/api/upload/avatar', formData, config).then(res => {
                                                        console.log('RES', res.data.fileNameInServer)
                                                        let filePath = res.data.fileNameInServer
                                                        if (res.data.status) {
                                                            alert("Thành công");
                                                        }
                                                        if (filePath) {
                                                            filePath = filePath.split('/')[1]
                                                        }
                                                        
                                                        this.setState({
                                                            imageUrl: 'http://localhost:8082/api/view-image/' + filePath
                                                        })
                                                    
                                                    })
                                                }}
                                                type="button"
                                            >
                                                UPLOAD
                                            </button>

                                        </Form>
                                     <Progress percentage={this.state.uploadPercentage} />

                                    </Col>
                                    {/* <Col sm={12} style={{paddingTop: 30}}>
                                        Thành công <br/>
                                        {
                                            this.state.imageUrl ? (
                                                <img src={this.state.imageUrl} alt=""/>
                                            ) : null
                                        }
                                    </Col> */}
                                </Row>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default App;
