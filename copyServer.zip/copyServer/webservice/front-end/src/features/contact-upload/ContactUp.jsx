import React, { Fragment, useState } from 'react';
// import PropTypes from "prop-types";
// import FileUpload from "components/FileUpload/FileUpload" 
import './App.css';
import axios from "axios"
const ContractUp = (
    // {
    // uploadImage
    // }
) => {
    
    const [name, setName] = useState('');
    const [file, setFile] = useState('');
    const [ManName, setMan] = useState('');
    const [filename, setFilename] = useState('Choose File');
    
    const formData = new FormData();
    const onChange = e => {
        setFile(e.target.files[0]);       
        setFilename(e.target.files[0].name);
      };

     const handleChange = event => {
        const target = event.target;
        const value = target.type === "checkbox" ? target.checked : target.value;
        // const name = target.name;
        setMan(value+'.jpg'); 
        setName(value);
     
      };

    const onClick1= e => {
        alert(name);
        e.preventDefault()
        if (!file) {
            alert('Bạn chưa chọn file.')
            return;
        }
        if (!name) {
            alert('Bạn chưa nhap ten.')
            return;
        }

        formData.append("file", file, ManName);
        formData.append("name", name);
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        }
        axios.post('http://localhost:8017/upload', formData, config).then(res => {
            console.log('RES', res.data.fileNameInServer)
            let filePath = res.data.fileNameInServer
            // if (filePath) {
            //     // NOTE: Vì tôi viết trên windows nên split theo dấu "\", nếu bạn chạy app trên Mac or linux mà gặp lỗi chỗ này thì xem xét đổi thành "/". nếu đổi sang "/" thì chỉ dùng 1 dấu "/" chứ ko phải hai dấu như "\\".
            //     filePath = filePath.split('\\')[1]
            // }
            // this.setState({
            //     imageUrl: 'http://localhost:8082/api/view-image/' + filePath
            // })
            alert(filePath);
        })
    }
    return ( 
  <div class="container">
  <div class="row">
      <div class="col-sm-8">
          <br/>
          <h4>
              Node.js upload files - trungquandev
          </h4>
          <div class=""></div>
          <form >
              <div class="form-group">
                  <label for="example-input-file"> </label>
                  <label htmlFor="name">Name*</label>
                    <input type="text" name="name" onChange={handleChange } placeholder="Name (required)" />
                  <input type="file" name="file" class="form-control-file border"  onChange={onChange}/>
              </div>
              
              <button type="button" class="btn btn-primary" onClick={onClick1} >Submit</button>
              <label >
                {filename}
                </label>
          </form>
      </div>
  </div>
</div>
);
};
// ContactUp.propTypes = {
//     uploadImage: PropTypes.func.isRequired,
//   };

export default ContractUp;
