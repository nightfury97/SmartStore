import React,{ useState, useCallback } from "react";
import PropTypes from "prop-types";
import Button from "components/button/Button";
import Gallery from "react-photo-gallery";
// import Gallery from "react-grid-gallery";
import Carousel, { Modal, ModalGateway } from "react-images";
import EXIF from "exif-js"
import axios, {post, get} from 'axios';
// import ImagePicker from 'react-native-image-picker';
import { photos } from "./photos";

const UncheckList = ( { unchecks,selectUncheck } ) => {

    

  const [currentImage, setCurrentImage] = useState(0);
  const [viewerIsOpen, setViewerIsOpen] = useState(false);
  const [name,setName] = useState("");
  const [filename,setfileName] = useState("");

  

  const openLightbox = useCallback((event, { photo}) => {
    // setCurrentImage(index);
    // alert(photo.alt);
    setName(photo.alt);
    setfileName(photo.nameImage);
    // this.forceUpdateHandler();
  }, []);

  const closeLightbox = () => {
    setCurrentImage(0);
    setViewerIsOpen(false);
  };

  const selectUn = useCallback((event, { photo}) => {
    selectUncheck(photo.data);
  }, []);

  const rotateImage = () => {
    var newimg = document.getElementsByClassName('image');
    EXIF.getData(newimg, function() {
      var orientation = EXIF.getTag(this, "Orientation");
      if(orientation == 6) {
          newimg.className = "camview rotate90";
      } else if(orientation == 8) {
          newimg.className = "camview rotate270";
      } else if(orientation == 3) {
          newimg.className = "camview rotate180";
      }
  });
  }
  const clickHandler = (data) =>{
    // moveFile('../../../../server/node-server/public/uncheck/'+data, '../../../../server/node-server/public/profile');
    const config = {
      headers: {
          'content-type': 'multipart/form-data'
      }
      }
      // post('http://localhost:8000/api/facial-recognition/confirm/'+data);
  
  }
  var divStyle = {
    color: 'black',
   
  };
  var divStyle2 = {
    color: 'black',
    backgroundColor: 'red',
    fontSize: '2rem',
  };



  var divStyle1 = {
    overflowY:'scroll',
    color: 'black',
    fontSize: '2rem',
  };

  return (  
    
    <div className="col-2 scroll" style={divStyle1}>
      <h1 style={{color:"black"}}>Danh sách phê duyệt</h1>
      {/* <div className="col-8"> */}
        <Gallery  
        className="scroll"
        onClick={selectUn}
        // onLoad={rotateImage}
        // onLoad={closeLightbox}
        // photos={photos}
          photos = {
            unchecks.map( uncheck =>({
              src: `http://localhost:8000/api/facial-recognition/file/uncheck%2F${uncheck.image}`,
              height: 1,              
              width: 1,
              data: uncheck,
              alt: uncheck.name,

                            
            }) )  
            
          }
        // direction={"column"}
        />
        {/* </div> */}

        {/* <div className="col-4 form-body">
        <label style={divStyle}>Name*</label>
        <input type="text" name="name" value={name}/>
        <Button style={divStyle2} label="Thêm" className="form-body" click={clickHandler(filename)}>Thêm</Button>       
        </div> */}
</div>
  );
};

UncheckList.propTypes = {
  unchecks: PropTypes.arrayOf( PropTypes.shape( {
    id: PropTypes.number.isRequired, 
    name: PropTypes.string.isRequired,
    age: PropTypes.oneOfType( [
      PropTypes.string,
      PropTypes.number ] ).isRequired,
    sex: PropTypes.string.isRequired,
    image: PropTypes.string,
  } ) ).isRequired,
  selectUncheck: PropTypes.func.isRequired,
};

UncheckList.defaultProps = {
};

export default UncheckList;

