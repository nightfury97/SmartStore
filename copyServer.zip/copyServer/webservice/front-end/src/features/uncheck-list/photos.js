  export const photos = [
    {
      src: "https://source.unsplash.com/2ShvY8Lf6l0/800x599",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/Dm-qxdynoEc/800x799",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/qDkso9nvCg0/600x799",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/iecJiKe_RNg/600x799",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/epcsn8Ed8kY/600x799",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/NQSWvyVRIJk/800x599",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/zh7GEuORbUw/600x799",
      width: 1,
      height: 1
    },
    {
      src: "https://source.unsplash.com/PpOHJezOalU/800x599",
      width: 1,
      height: 1
    },
    {
      src: "http://localhost:8000/api/facial-recognition/file/uncheck%2FNgoc.jpg",
      width: 1,
      height: 1
    }
  ];

  // import { HTTP } from "constants/constants";
  // let contactUrl = HTTP.DATA_ALL_UNCHECK
  // var data = fetch( contactUrl );
  // export const photos = {
    
  // }
  