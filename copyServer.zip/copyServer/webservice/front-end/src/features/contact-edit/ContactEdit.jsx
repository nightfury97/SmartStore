import React from "react";
import PropTypes from "prop-types";
import DataformEdit from "components/dataform/DataformEdit";
import "./ContactEdit.css";

const ContactEdit = ({ active, currentId, profile, editContact, cancelEditContact }) => {
  let classes = "contact-edit-container";
  let imageToUse;
  if (active) classes += " active";

  if ( profile.id ) {
    imageToUse = `http://localhost:8000/api/facial-recognition/file/profile%2F${ profile.name }.0.jpg`;
  }

  return (
    <div className={classes} key={currentId}>
      <div className="contact-image-capture">
        <div className="contact-image"><img src={imageToUse} alt={profile.name} /></div>
      </div>
      <div className="contact-detail-form">
        <h2>Personal Information</h2>
        <DataformEdit
          currentId={currentId}
          profile={profile}
          cancelEditContact={cancelEditContact}
          editContact={editContact}
        />
      </div>
    </div>
  );
};

ContactEdit.propTypes = {
  currentId: PropTypes.string.isRequired,
  active: PropTypes.bool,
  profile: PropTypes.shape({
    id: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    clearanceType: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    position: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
    height: PropTypes.string.isRequired,
    weight: PropTypes.string.isRequired,
    phone: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
  }),
  cancelEditContact: PropTypes.func.isRequired,
  editContact: PropTypes.func.isRequired,
};

ContactEdit.defaultProps = {
  active: true,
  profile: {
    id: "",
    image: "",
    name: "",
    clearanceType: "",
    status: "",
    position: "",
    age: 0,
    height: "",
    weight: "",
    phone: "",
    email: "",
  },
};
export default ContactEdit;
