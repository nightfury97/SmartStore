import React,{ useState, useCallback } from "react";
import PropTypes from "prop-types";
import Button from "components/button/Button";
import Gallery from "react-photo-gallery";
// import Gallery from "react-grid-gallery";
import Carousel, { Modal, ModalGateway } from "react-images";
import EXIF from "exif-js"
import axios, {post, get} from 'axios';
// import ImagePicker from 'react-native-image-picker';
import { photos } from "./photos";

 
const UncheckDetails = ( { uncheck,imageList } ) => {
  let bodyClasses = "form-body";
  var divStyle = {
    color: 'black',
    // backgroundColor: 'red',
    fontSize: '1.4rem',
    paddingTop: '5px',
    paddingLeft: '20px'
  };
  var divStyle1 = {

    paddingRight: '20px'
  };


// class UncheckDetails extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       uncheck: this.props.uncheck,
//       imageList:this.props.imageList,
//       // name: this.props.profile.name,
//       // clearanceType: this.props.profile.clearanceType,
//       // position: this.props.profile.position,
//       // age: this.props.profile.age,
//       // height: this.props.profile.height,
//       // weight: this.props.profile.weight,
//       // phone: this.props.profile.phone,
//       // email: this.props.profile.email,
//       // disableSave: true,
//     };
//     this.aler = this.aler.bind(this);
//   }

const  aler =() =>{
    alert("image list: "+ imageList.length)
  
  };

  // // render(){
  //   let bodyClasses = "form-body";
  // var divStyle = {
  //   color: 'black',
  //   // backgroundColor: 'red',
  //   fontSize: '1.4rem',
  //   paddingTop: '5px',
  //   paddingLeft: '20px'
  // };
  // var divStyle1 = {

  //   paddingRight: '20px'
  // };
  

  
  return (  
    
    <div className="col-4">
      <div className="row">
      <form name="confirmUncheck">
        <div className={bodyClasses}>
          <label htmlFor="name" style={divStyle}>Tên*</label>
          <input type="text" name="name" value={uncheck.name}   />
          <label htmlFor="age" style={divStyle}>Tuổi</label>
          <input type="number" name="age" value={uncheck.age}  />
          <label htmlFor="sex" style={divStyle} onClick={aler}>Giới tính</label>
          <select name="sex" value={uncheck.sex}  >
            <option value="Nam">Nam</option>
            <option value="Nữ">Nữ</option>
          </select>
          {/* <label htmlFor="position">Position</label>
          <input type="text" name="position" value={this.state.position} placeholder="job title" onChange={this.handleChange} />
          
          <label htmlFor="height">Height</label>
          <input type="text" name="height" value={this.state.height} placeholder="height" onChange={this.handleChange} />
          <label htmlFor="weight">Weight</label>
          <input type="text" name="weight" value={this.state.weight} placeholder="weight" onChange={this.handleChange} />
          <label htmlFor="phone">Phone Number</label>
          <input type="text" name="phone" value={this.state.phone} placeholder="e.g. 555 555 5555" onChange={this.handleChange} />
          <label htmlFor="email">Email</label>
          <input type="email" name="email" value={this.state.email} placeholder="user@example.com" onChange={this.handleChange} /> */}
        </div>
          <div className="form-footer" style={divStyle1}>
            <Button label="Cancel" type="button" addClass="btn-cancel" />
            <Button label="Save" type="button" addClass="btn-save" />
          </div>
        </form>
      </div>
      <div className="row">
        {imageList.map(() => {
          return(
          <Button label="Save" type="button" addClass="btn-save" />
            )
        })}
                {/* <Gallery  
      
       
          photos = {
            imageList.map( uncheck =>({
              src: `http://localhost:8000/api/facial-recognition/file/uncheck%2F${uncheck.image}`,
              height: 1,              
              width: 1,
              alt: uncheck.name,
              id: uncheck.id,

              sizes : ["(max-width: 480px) 50vw,(max-width: 1024px) 33.3vw,100vw"],
              thumbnailWidth: 240,
              thumbnailHeight: 320,
              class: "image"              
            }) )       
          }
        /> */}
      </div>

        
 
    </div>
  )}
// }


UncheckDetails.propTypes = {
  uncheck: PropTypes.shape({
    // id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
    sex: PropTypes.string.isRequired
  }).isRequired,
  imageList: PropTypes.arrayOf( PropTypes.shape( {
    id: PropTypes.int,
    image: PropTypes.string,
    name: PropTypes.string.isRequired,
  } ) ).isRequired,
};

UncheckDetails.defaultProps = {
};

export default UncheckDetails;

