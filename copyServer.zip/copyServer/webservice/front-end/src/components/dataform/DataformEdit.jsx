import React from "react";
import PropTypes from "prop-types";
import Button from "components/button/Button";
import { CLEARANCE } from "../../constants/constants";

class DataFormEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      id: this.props.profile.id,
      name: this.props.profile.name,
      clearanceType: this.props.profile.clearanceType,
      position: this.props.profile.position,
      age: this.props.profile.age,
      height: this.props.profile.height,
      weight: this.props.profile.weight,
      phone: this.props.profile.phone,
      email: this.props.profile.email,
      disableSave: true,
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event) {
    const target = event.target;
    const value = target.type === "checkbox" ? target.checked : target.value;
    const name = target.name;
    this.setState({
      [name]: value,
    });

    if (this.state.name !== "") {
      this.setState({ disableSave: false });
    }
  }

  render() {
    let bodyClasses = "form-body";
    return (
      <form name="addContact">
        <div className={bodyClasses}>
          <label htmlFor="name">Name*</label>
          <input type="text" name="name" value={this.state.name} placeholder="Name (required)" onChange={this.handleChange} />
          <label htmlFor="clearanceType">Clearance</label>
          <select name="clearanceType" value={this.state.clearanceType} onChange={this.handleChange} >
            <option value="A">{CLEARANCE.A}</option>
            <option value="B">{CLEARANCE.B}</option>
            <option value="C">{CLEARANCE.C}</option>
            <option value="D">{CLEARANCE.D}</option>
          </select>
          <label htmlFor="position">Position</label>
          <input type="text" name="position" value={this.state.position} placeholder="job title" onChange={this.handleChange} />
          <label htmlFor="age">Age</label>
          <input type="text" name="age" value={this.state.age} placeholder="age" onChange={this.handleChange} />
          <label htmlFor="height">Height</label>
          <input type="text" name="height" value={this.state.height} placeholder="height" onChange={this.handleChange} />
          <label htmlFor="weight">Weight</label>
          <input type="text" name="weight" value={this.state.weight} placeholder="weight" onChange={this.handleChange} />
          <label htmlFor="phone">Phone Number</label>
          <input type="text" name="phone" value={this.state.phone} placeholder="e.g. 555 555 5555" onChange={this.handleChange} />
          <label htmlFor="email">Email</label>
          <input type="email" name="email" value={this.state.email} placeholder="user@example.com" onChange={this.handleChange} />
        </div>
        <div className="form-footer">
          <Button label="Cancel" type="button" addClass="btn-cancel" click={this.props.cancelEditContact} />
          <Button label="Save" type="button" addClass="btn-save" click={this.props.editContact} disabled={this.state.disableSave} data={this.state} />
        </div>
      </form>
    );
  }
}

DataFormEdit.propTypes = {
  currentId: PropTypes.string,
  cancelEditContact: PropTypes.func.isRequired,
  editContact: PropTypes.func.isRequired,
};


export default DataFormEdit;
