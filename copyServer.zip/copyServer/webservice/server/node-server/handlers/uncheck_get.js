/**
* profiles_get
*
* GET: /api/facial-recognition/unchecks
* 
*/
exports.handler = function profiles_get(req, res, next) {
    console.log(`Getting all uncheck.`);
    db.getAllUncheck(function (results) {
        console.log(`Results: ${JSON.stringify(results)}`);
        
        if (results.status === db.SUCCESS) {
           res.send(200, results);
       } else {
           console.log('failure');
           res.send(500, results);
       }
       next();
    });
};