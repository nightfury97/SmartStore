//moves the $file to $dir2


//move file1.htm from 'test/' to 'test/dir_1/'

exports.handler = function move_file(req, res, next) {
  console.log(`move: ${JSON.stringify(req.body)}`);
  var flag =req.body.confirm;
  if(flag==1)
  {
    var name= req.body.name;
    var age = req.body.age;
    var sex = req.body.sex;
    var imgs = req.body.img;
    var IdDel=req.body.uncheck.id;
    var firstImage=req.body.uncheck.image;
    var fs = require('fs');
    var path = require('path');
    var filename = "";
    var image ="";
    if (imgs) {
      imgs.forEach(function(img) {
        var pathImg="./public/profile/";
        var nameImg="";
        if (img.indexOf('-') != -1) {
          filename=img.slice(0, img.indexOf("-"));
          pathImg+=img.slice(0, img.indexOf("-"))+"/";
          nameImg=img.slice(0, img.indexOf("-"))+"/"+img;
        }
        image=img;
        console.log("img: "+img);
        console.log("pathh: "+pathImg);
        console.log("filename: "+filename);
        
        if (!fs.existsSync(pathImg)) {
          console.log("make " + pathImg)
          fs.mkdirSync(pathImg);
        }

        var f = path.basename('./public/uncheck/'+nameImg);
        var dest = path.resolve(pathImg, f);
      
        fs.rename('./public/uncheck/'+nameImg, dest, (err)=>{
          if(err) throw err;
          else console.log('Successfully moved');
        });

        db.addProfileImg(name,img,results =>{
          console.log(`Results addProfileImg: ${JSON.stringify(results)}`); 
          if (results.status === db.SUCCESS) {
            db.delUncheckImg(img,results =>{
              // if(img==firstImage)
              // {
              //   db.updateUncheckImage(IdDel,name);
              // }
            console.log(`Results delUncheckImg: ${JSON.stringify(results)}`);              
            })
          } else {
            console.log(`Results delUncheckImg: FAIL`);           
        }});
        // if(flag==1)
        // {
        //   var pathAudio="./public/profile/"+img.slice(0, img.indexOf("-"))+"/";;
        //   var nameAudio=img.slice(0, img.indexOf("-"))+"/"+img.slice(0, img.indexOf("-"))+"-name.mp3";
        //   var f = path.basename('./public/uncheck/'+nameAudio);
        //   var dest = path.resolve(pathImg, f);
        
        //   fs.rename('./public/uncheck/'+nameAudio, dest, (err)=>{
        //     if(err) throw err;
        //     else console.log('Successfully moved mp3');
        //   });
        // }
        }              
      )}
    db.addProfileByUncheck(name,age,sex,image,results =>{console.log(`Results add: ${JSON.stringify(results)}`);});
    db.deleteUncheck(IdDel,results =>{console.log(`Results del: ${JSON.stringify(results)}`);})
    var nameAudio=filename+"/"+filename+"-name.mp3";
    var f = path.basename('./public/uncheck/'+nameAudio);
    var pathAudio = "./public/profile/"+filename+"/";
    var dest = path.resolve(pathAudio, f);
  
    fs.rename('./public/uncheck/'+nameAudio, dest, (err)=>{
      if(err) throw err;
      else console.log('Successfully moved mp3');
    }); 
    mqtt.publish("commands/name", filename+"/"+image);
    res.send(200, 'OK');
      next();
  }
  else if(flag==2)
  {
    // var name= req.body.name;
    // var age = req.body.age;
    // var sex = req.body.sex;
    var IdAdd=req.body.id;
    var imgs = req.body.img;
    var IdDel=req.body.uncheck.id;
    var firstImage=req.body.uncheck.image;
    var fs = require('fs');
    var path = require('path');
    var filename = "";
    var image ="";
    if (imgs) {
      imgs.forEach(function(img) {
        var pathImg="./public/profile/";
        var nameImg="";
        if (img.indexOf('-') != -1) {
          filename=img.slice(0, img.indexOf("-"));
          pathImg+=img.slice(0, img.indexOf("-"))+"/";
          nameImg=img.slice(0, img.indexOf("-"))+"/"+img;
        }
        image=img;
        console.log("img: "+img);
        console.log("pathh: "+pathImg);
        console.log("filename: "+filename);
        
        if (!fs.existsSync(pathImg)) {
          console.log("make " + pathImg)
          fs.mkdirSync(pathImg);
        }

        var f = path.basename('./public/uncheck/'+nameImg);
        var dest = path.resolve(pathImg, f);
      
        fs.rename('./public/uncheck/'+nameImg, dest, (err)=>{
          if(err) throw err;
          else console.log('Successfully moved');
        });

        // db.addProfileImg(name,img,results =>{
        //   console.log(`Results addProfileImg: ${JSON.stringify(results)}`); 
        //   if (results.status === db.SUCCESS) {
        //     db.delUncheckImg(img,results =>{
        //       // if(img==firstImage)
        //       // {
        //       //   db.updateUncheckImage(IdDel,name);
        //       // }
        //     console.log(`Results delUncheckImg: ${JSON.stringify(results)}`);              
        //     })
        //   } else {
        //     console.log(`Results delUncheckImg: FAIL`);           
        // }});
        
        }              
      )}
  
    db.deleteUncheck(IdDel,results =>{console.log(`Results del: ${JSON.stringify(results)}`);})
    
    mqtt.publish("commands/name", filename+"/"+image);
    res.send(200, 'OK');
      next();
  }
  else
  {
    db.deleteUncheck(IdDel,results =>{console.log(`Results: ${JSON.stringify(results)}`);});
    res.send(200, 'OK');

  }
 
 
    next();
};