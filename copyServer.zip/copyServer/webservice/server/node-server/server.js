const swaggerRoutes = require('swagger-routes');
const restify = require('restify');
const config = require('./config');

const server = restify.createServer(config.restify.options);

/*  We create a global db variable because it needs to be referenced by the handlers.
    This is not ideal but, I couldn't figure out how to inject it and use the swagger-routes
    to automatically generate handlers.
 */
db = require('./db/sqlite.js');
db.open(config);

server.use(restify.plugins.bodyParser({ mapParams: true }));
server.use(restify.plugins.queryParser({ mapParams: true }));


const corsMiddleware = require('restify-cors-middleware')
 
const cors = corsMiddleware({
  preflightMaxAge: 5, //Optional 
  origins: ['*'],
  allowHeaders: ['Access-Control-Allow-Origin'],
  exposeHeaders: ['API-Token-Expiry']
})
 
server.pre(cors.preflight)
server.use(cors.actual)


/*  swagger-routes package automatically generates our handlers based on the swagger.json. */
swaggerRoutes(server, {
    api: config.api,
    handlers:  {
        path: './handlers',
        template: './handlers/template.mustache'
    }
});

server.listen(config.restify.port);

/*  This is another of those global variables....*/
mqtt = require('./mqtt');
mqtt.configure(config);
mqtt.start();





// const swaggerRoutes = require('swagger-routes');
// const restify = require('restify');
// const config = require('./config');

 
// let express = require("express");
// let multer = require("multer");
// let path = require("path");
// let bodyParser = require("body-parser");
 
// let app = express();
// // Khai báo sử dụng body-parser để nhận data từ form
// app.use(bodyParser.urlencoded({extended: true}));

// const server = restify.createServer(config.restify.options);
// const db = require('./db/sqlite.js');
// db.open(config);

// server.use(restify.plugins.bodyParser({ mapParams: true }));
// server.use(restify.plugins.queryParser({ mapParams: true }));


// const corsMiddleware = require('restify-cors-middleware')
 
// const cors = corsMiddleware({
//   preflightMaxAge: 5, //Optional 
//   origins: ['*'],
//   allowHeaders: ['Access-Control-Allow-Origin'],
//   exposeHeaders: ['API-Token-Expiry']
// })
 
// server.pre(cors.preflight)
// server.use(cors.actual)


// /*  swagger-routes package automatically generates our handlers based on the swagger.json. */
// swaggerRoutes(server, {
//     api: config.api,
//     handlers:  {
//         path: './handlers',
//         template: './handlers/template.mustache'
//     }
// });

// server.listen(config.restify.port);

// /*  This is another of those global variables....*/
// const mqtt = require('./mqtt');
// mqtt.configure(config);
// mqtt.start();

 
// // Route này trả về cái form upload cho client
// // Khởi tạo biến cấu hình cho việc lưu trữ file upload
// let diskStorage = multer.diskStorage({
//   destination: (req, file, callback) => {
//     // Định nghĩa nơi file upload sẽ được lưu lại
//     callback(null, "public/profile");
//   },
//   filename: (req, file, callback) => {
//     // ở đây các bạn có thể làm bất kỳ điều gì với cái file nhé.
//     // Mình ví dụ chỉ cho phép tải lên các loại ảnh png & jpg
//     let math = ["image/png", "image/jpeg"];
//     if (math.indexOf(file.mimetype) === -1) {
//       let errorMess = `The file <strong>${file.originalname}</strong> is invalid. Only allowed to upload image jpeg or png.`;
//       return callback(errorMess, null);
//     }
    
    
//     // Tên của file thì mình nối thêm một cái nhãn thời gian để đảm bảo không bị trùng.
//     let filename = `${file.originalname}`;
//     callback(null, filename);
//   }
// });
 
// // Khởi tạo middleware uploadFile với cấu hình như ở trên,
// // Bên trong hàm .single() truyền vào name của thẻ input, ở đây là "file"
// let uploadFile = multer({storage: diskStorage}).single("file");
 
// // Route này Xử lý khi client thực hiện hành động upload file
// app.post("/upload", (req, res,next) => {

//   // Thực hiện upload file, truyền vào 2 biến req và res
//   uploadFile(req, res, (error) => {
//     // Nếu có lỗi thì trả về lỗi cho client.
//     // Ví dụ như upload một file không phải file ảnh theo như cấu hình của mình bên trên
//     if (error) {
//       return res.send(`Error when trying to upload: ${error}`);
//     }

//     console.log(`------Request body-----`);
//     console.log(req.body);
    
//     console.log(`------Request file-----`);
    // console.log(req.file);


//     console.log(`------Test Done-----`);
  
//     // db2.insertImage(req.body.name);
//     next();
//     mqtt.publish("commands/name2",req.body.name);
//     res.redirect('http://localhost:8080/directory');
//     // Không có lỗi thì lại render cái file ảnh về cho client.
//     // Đồng thời file đã được lưu vào thư mục uploads
//     // res.sendFile(path.join(`${__dirname}/uploads/${req.file.filename}`));
//   });
// });
 
// app.listen(8017, "localhost", () => {
//   console.log(`I'm running at localhost:8017/`);
// });