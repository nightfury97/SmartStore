import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App.js";
import 'bootstrap/dist/css/bootstrap.min.css'; // <---- thêm đoạn này   
const x = <App />
ReactDOM.render(x, document.getElementById("root"));
