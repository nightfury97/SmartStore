The webservice comprises of two parts:
 * Server
 * Front-end (client)

Details on how to install and run are given individually in the corresponding readmes.

Before you begin also install the following prerequisites:

    sudo apt update
    sudo apt install npm nodejs nodejs-dev nodejs-legacy
    sudo apt install libzmq3-dev libkrb5-dev

The webservice will function correctly with Node 4 LTS or newer.

