// Copyright (C) 2018-2019 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

#include "cnn.hpp"

#include <string>
#include <vector>
#include <algorithm>

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <samples/slog.hpp>

#include <inference_engine.hpp>

using namespace InferenceEngine;

CnnDLSDKBase::CnnDLSDKBase(const Config &config) : config_(config) {}

bool CnnDLSDKBase::Enabled() const
{
    return config_.enabled;
}

void CnnDLSDKBase::Load()
{
    CNNNetReader net_reader;
    net_reader.ReadNetwork(config_.path_to_model);
    net_reader.ReadWeights(config_.path_to_weights);

    if (!net_reader.isParseSuccess())
    {
        THROW_IE_EXCEPTION << "Cannot load model";
    }

    const int currentBatchSize = net_reader.getNetwork().getBatchSize();
    if (currentBatchSize != config_.max_batch_size)
        net_reader.getNetwork().setBatchSize(config_.max_batch_size);

    InferenceEngine::InputsDataMap in = net_reader.getNetwork().getInputsInfo();
    if (in.size() != 1)
    {
        THROW_IE_EXCEPTION << "Network should have only one input";
    }
    in.begin()->second->setInputPrecision(Precision::U8);
    in.begin()->second->setLayout(Layout::NCHW);
    input_blob_name_ = in.begin()->first;

    OutputsDataMap out = net_reader.getNetwork().getOutputsInfo();
    for (auto &&item : out)
    {
        item.second->setPrecision(Precision::FP32);
        output_blobs_names_.push_back(item.first);
    }

    executable_network_ = config_.plugin.LoadNetwork(net_reader.getNetwork(), {});
    infer_request_ = executable_network_.CreateInferRequest();
}

void CnnDLSDKBase::InferBatch(
    const std::vector<cv::Mat> &frames,
    std::function<void(const InferenceEngine::BlobMap &, size_t)> fetch_results) const
{
    if (!config_.enabled)
    {
        return;
    }
    Blob::Ptr input = infer_request_.GetBlob(input_blob_name_);
    const size_t batch_size = input->getTensorDesc().getDims()[0];

    size_t num_imgs = frames.size();
    for (size_t batch_i = 0; batch_i < num_imgs; batch_i += batch_size)
    {
        const size_t current_batch_size = std::min(batch_size, num_imgs - batch_i);
        for (size_t b = 0; b < current_batch_size; b++)
        {
            matU8ToBlob<uint8_t>(frames[batch_i + b], input, b);
        }

        infer_request_.SetBatch(current_batch_size);
        infer_request_.Infer();

        InferenceEngine::BlobMap blobs;
        for (const auto &name : output_blobs_names_)
        {
            blobs[name] = infer_request_.GetBlob(name);
        }
        fetch_results(blobs, current_batch_size);
    }
}

void CnnDLSDKBase::PrintPerformanceCounts() const
{
    if (!config_.enabled)
    {
        return;
    }
    std::cout << "Performance counts for " << config_.path_to_model << std::endl
              << std::endl;
    ::printPerformanceCounts(infer_request_.GetPerformanceCounts(), std::cout, false);
}

void CnnDLSDKBase::Infer(const cv::Mat &frame,
                         std::function<void(const InferenceEngine::BlobMap &, size_t)> fetch_results) const
{
    InferBatch({frame}, fetch_results);
}

VectorCNN::VectorCNN(const Config &config)
    : CnnDLSDKBase(config)
{
    if (config.enabled)
    {
        Load();
        if (output_blobs_names_.size() != 1)
        {
            THROW_IE_EXCEPTION << "Demo supports topologies only with 1 output";
        }
    }
}

void VectorCNN::Compute(const cv::Mat &frame,
                        cv::Mat *vector, cv::Size outp_shape) const
{
    std::vector<cv::Mat> output;
    Compute({frame}, &output, outp_shape);
    *vector = output[0];
}

void VectorCNN::Compute(const std::vector<cv::Mat> &images, std::vector<cv::Mat> *vectors,
                        cv::Size outp_shape) const
{
    if (images.empty())
    {
        return;
    }
    vectors->clear();
    auto results_fetcher = [vectors, outp_shape](const InferenceEngine::BlobMap &outputs, size_t batch_size) {
        for (auto &&item : outputs)
        {
            InferenceEngine::Blob::Ptr blob = item.second;
            if (blob == nullptr)
            {
                THROW_IE_EXCEPTION << "VectorCNN::Compute() Invalid blob '" << item.first << "'";
            }
            InferenceEngine::SizeVector ie_output_dims = blob->getTensorDesc().getDims();
            std::vector<int> blob_sizes(ie_output_dims.size(), 0);
            for (size_t i = 0; i < blob_sizes.size(); ++i)
            {
                blob_sizes[i] = ie_output_dims[i];
            }
            cv::Mat out_blob(blob_sizes, CV_32F, blob->buffer());
            for (size_t b = 0; b < batch_size; b++)
            {
                cv::Mat blob_wrapper(out_blob.size[1], 1, CV_32F,
                                     reinterpret_cast<void *>((out_blob.ptr<float>(0) + b * out_blob.size[1])));
                vectors->emplace_back();
                if (outp_shape != cv::Size())
                    blob_wrapper = blob_wrapper.reshape(1, {outp_shape.height, outp_shape.width});
                blob_wrapper.copyTo(vectors->back());
            }
        }
    };

    InferBatch(images, results_fetcher);
}







BaseDetection::BaseDetection(std::string topoName,
                             const std::string &pathToModel,
                             const std::string &deviceForInference,
                             int maxBatch, bool isBatchDynamic, bool isAsync,
                             bool doRawOutputMessages)
    : plugin(nullptr), topoName(topoName), pathToModel(pathToModel), deviceForInference(deviceForInference),
      maxBatch(maxBatch), isBatchDynamic(isBatchDynamic), isAsync(isAsync),
      enablingChecked(false), _enabled(false), doRawOutputMessages(doRawOutputMessages) {
    if (isAsync) {
        slog::info << "Use async mode for " << topoName << slog::endl;
    }
}

BaseDetection::~BaseDetection() {}

ExecutableNetwork* BaseDetection::operator ->() {
    return &net;
}

void BaseDetection::submitRequest() {
    if (!enabled() || request == nullptr) return;
    if (isAsync) {
        request->StartAsync();
    } else {
        request->Infer();
    }
}

void BaseDetection::wait() {
    if (!enabled()|| !request || !isAsync)
        return;
    request->Wait(IInferRequest::WaitMode::RESULT_READY);
}

bool BaseDetection::enabled() const  {
    if (!enablingChecked) {
        _enabled = !pathToModel.empty();
        if (!_enabled) {
            slog::info << topoName << " DISABLED" << slog::endl;
        }
        enablingChecked = true;
    }
    return _enabled;
}

void BaseDetection::printPerformanceCounts() {
    if (!enabled()) {
        return;
    }
    slog::info << "Performance counts for " << topoName << slog::endl << slog::endl;
    ::printPerformanceCounts(request->GetPerformanceCounts(), std::cout, false);
}



HeadPoseDetection::HeadPoseDetection(const std::string &pathToModel,
                                     const std::string &deviceForInference,
                                     int maxBatch, bool isBatchDynamic, bool isAsync, bool doRawOutputMessages)
    : BaseDetection("Head Pose", pathToModel, deviceForInference, maxBatch, isBatchDynamic, isAsync, doRawOutputMessages),
      outputAngleR("angle_r_fc"), outputAngleP("angle_p_fc"), outputAngleY("angle_y_fc"), enquedFaces(0) {
}

void HeadPoseDetection::submitRequest()  {
    if (!enquedFaces) return;
    if (isBatchDynamic) {
        request->SetBatch(enquedFaces);
    }
    BaseDetection::submitRequest();
    enquedFaces = 0;
}

void HeadPoseDetection::enqueue(const cv::Mat &face) {
    if (!enabled()) {
        return;
    }
    if (enquedFaces == maxBatch) {
        slog::warn << "Number of detected faces more than maximum(" << maxBatch << ") processed by Head Pose estimator" << slog::endl;
        return;
    }
    if (!request) {
        request = net.CreateInferRequestPtr();
    }

    Blob::Ptr inputBlob = request->GetBlob(input);

    matU8ToBlob<uint8_t>(face, inputBlob, enquedFaces);

    enquedFaces++;
}

HeadPoseDetection::Results HeadPoseDetection::operator[] (int idx) const {
    Blob::Ptr  angleR = request->GetBlob(outputAngleR);
    Blob::Ptr  angleP = request->GetBlob(outputAngleP);
    Blob::Ptr  angleY = request->GetBlob(outputAngleY);

    HeadPoseDetection::Results r = {angleR->buffer().as<float*>()[idx],
                                    angleP->buffer().as<float*>()[idx],
                                    angleY->buffer().as<float*>()[idx]};

    if (doRawOutputMessages) {
        std::cout << "[" << idx << "] element, yaw = " << r.angle_y <<
                     ", pitch = " << r.angle_p <<
                     ", roll = " << r.angle_r << std::endl;
    }

    return r;
}

CNNNetwork HeadPoseDetection::read() {
    slog::info << "Loading network files for Head Pose Estimation network" << slog::endl;
    CNNNetReader netReader;
    // Read network model
    netReader.ReadNetwork(pathToModel);
    // Set maximum batch size
    netReader.getNetwork().setBatchSize(maxBatch);
    slog::info << "Batch size is set to  " << netReader.getNetwork().getBatchSize() << " for Head Pose Estimation network" << slog::endl;
    // Extract model name and load its weights
    std::string binFileName = fileNameNoExt(pathToModel) + ".bin";
    netReader.ReadWeights(binFileName);

    // ---------------------------Check inputs -------------------------------------------------------------
    slog::info << "Checking Head Pose Estimation network inputs" << slog::endl;
    InputsDataMap inputInfo(netReader.getNetwork().getInputsInfo());
    if (inputInfo.size() != 1) {
        throw std::logic_error("Head Pose Estimation network should have only one input");
    }
    InputInfo::Ptr& inputInfoFirst = inputInfo.begin()->second;
    inputInfoFirst->setPrecision(Precision::U8);
    input = inputInfo.begin()->first;
    // -----------------------------------------------------------------------------------------------------

    // ---------------------------Check outputs ------------------------------------------------------------
    slog::info << "Checking Head Pose Estimation network outputs" << slog::endl;
    OutputsDataMap outputInfo(netReader.getNetwork().getOutputsInfo());
    if (outputInfo.size() != 3) {
        throw std::logic_error("Head Pose Estimation network should have 3 outputs");
    }
    for (auto& output : outputInfo) {
        output.second->setPrecision(Precision::FP32);
    }
    std::map<std::string, bool> layerNames = {
        {outputAngleR, false},
        {outputAngleP, false},
        {outputAngleY, false}
    };

    for (auto && output : outputInfo) {
        CNNLayerPtr layer = output.second->getCreatorLayer().lock();
        if (!layer) {
            throw std::logic_error("Layer pointer is invalid");
        }
        if (layerNames.find(layer->name) == layerNames.end()) {
            throw std::logic_error("Head Pose Estimation network output layer unknown: " + layer->name + ", should be " +
                                   outputAngleR + " or " + outputAngleP + " or " + outputAngleY);
        }
        if (layer->type != "FullyConnected") {
            throw std::logic_error("Head Pose Estimation network output layer (" + layer->name + ") has invalid type: " +
                                   layer->type + ", should be FullyConnected");
        }
        auto fc = dynamic_cast<FullyConnectedLayer*>(layer.get());
        if (!fc) {
            throw std::logic_error("Fully connected layer is not valid");
        }
        if (fc->_out_num != 1) {
            throw std::logic_error("Head Pose Estimation network output layer (" + layer->name + ") has invalid out-size=" +
                                   std::to_string(fc->_out_num) + ", should be 1");
        }
        layerNames[layer->name] = true;
    }

    slog::info << "Loading Head Pose Estimation model to the "<< deviceForInference << " plugin" << slog::endl;

    _enabled = true;
    return netReader.getNetwork();
}


Load::Load(BaseDetection& detector) : detector(detector) {
}

void Load::into(InferencePlugin & plg, bool enable_dynamic_batch) const {
    if (detector.enabled()) {
        std::map<std::string, std::string> config;
        std::string pluginName = plg.GetVersion()->description;
        bool isPossibleDynBatch = pluginName.find("MKLDNN") != std::string::npos ||
                                  pluginName.find("clDNN") != std::string::npos;
        if (enable_dynamic_batch && isPossibleDynBatch) {
            config[PluginConfigParams::KEY_DYN_BATCH_ENABLED] = PluginConfigParams::YES;
        }
        detector.net = plg.LoadNetwork(detector.read(), config);
        detector.plugin = &plg;
    }
}

