import re
import sys
import os

frame = -1
last_frame = -1
last_bboxes = [None]
last_bbox = []
last_pid = -1
lst_dist = 999
last_frame_with_face = -1
last_diff_frame = -1
last_same_frame = -1

log = []
log_temp_debug = []
log_debug = []
log_dict = {}

frames_with_face = []
face_num = 0
faces = []
frame_time = []


faces_num = []
faces_in_frame = []
last_bboxes = []
last_same_frames = []
last_diff_frames = []
last_pids = []


filepath = '/media/tunguyen/Others/FaceReg/video/out1.1.1208_cropped/log.txt'

if len(sys.argv) == 2:
    filepath = sys.argv[1]

fp = open(filepath)


line = fp.readline()
while line:
    data = line.strip()

    if "@" in data:
        frame = int(re.search('\@(.*)\:\:', data).group(1))
        face_num = 0
        faces = []
        frame_time.append(re.search('\:\:(.*)', data).group(1))

    # face detected
    if "*" in data:
        bboxs = re.search('\*\[(.*)\]', data)
        bbox = bboxs.group(1).split(',')
        bbox = [float(i) for i in bbox]

        person = re.search('\((.*)\<(.*)\>\)', data)
        pid = person.group(1)
        dist = float(person.group(2))

        x = bbox[0]
        y = bbox[1]
        w = bbox[2]
        h = bbox[3]
        bbox.append(pid)
        bbox.append(dist)

        face_num += 1
        faces.append(bbox)

        if not frame in frames_with_face:
            frames_with_face.append(frame)
            faces_num.append(face_num)
            faces_in_frame.append(faces)
        else:
            frames_with_face[-1] = frame
            faces_num[-1] = face_num
            faces_in_frame[-1] = faces

    line = fp.readline()


faces_in_frame = [sorted(bboxes, key=lambda x: int(x[0]))
                  for bboxes in faces_in_frame]
# print(faces_in_frame)

last_key_log = {}

for idx, frame in enumerate(frames_with_face):
    bboxes = faces_in_frame[idx]
    face_num = faces_num[idx]

    last_bboxes = faces_in_frame[idx-1]

    for fnum in range(0, face_num):
        bbox = bboxes[fnum]

        print(frame, bbox, fnum, len(last_bboxes))

        x = bbox[0]
        y = bbox[1]
        w = bbox[2]
        h = bbox[3]
        pid = bbox[4]
        dist = bbox[5]

        last_frame = frames_with_face[idx-1]

        for idx_last_bbox, last_bbox in enumerate(last_bboxes):

            last_x = last_bbox[0]
            last_y = last_bbox[1]
            last_w = last_bbox[2]
            last_h = last_bbox[3]

            missing_frame = frame - frames_with_face[idx-1]
            change_x = abs(x - last_x)
            change_y = abs(y - last_y)

            key_log = '{}_{}'.format(frame, fnum)

            print('key_log', key_log, 'idx_last_bbox', idx_last_bbox)

            if missing_frame <= 6 and change_x <= 25*missing_frame and change_y <= 25*missing_frame:
                print('\tsame person')

                log_dict[key_log] = '{}-{}-{}-{}-{}'.format(key_log, 0, pid, dist, 1)
                last_key_log[key_log] = '{}_{}'.format(last_frame, idx_last_bbox)

                break
            else:
                print('\tdifferent person')

                last_key_log[key_log] = '-1'

                if not key_log in log_dict:
                    log_dict[key_log] = '{}-{}-{}-{}-{}'.format(key_log, 1, pid, dist, 0)
            
            # print(last_key_log[key_log])

        print('\tlast_bboxes: \t\t{}'.format(last_bboxes))


last_key_log_sorted = sorted(last_key_log.items(), key=lambda x: (int(x[0].split('_')[0])), reverse=True)
# print(last_key_log)
# print(last_key_log_sorted)
frames_of_face = {}
root_frames = {}
for key_log, prev_key_log in last_key_log_sorted:
    if prev_key_log != -1:
        final_start_key_log = prev_key_log
        start_key_log = prev_key_log
        while start_key_log != '-1':
            start_key_log = last_key_log[start_key_log]
            if start_key_log != '-1':
                final_start_key_log = start_key_log
        root_frames[key_log] = final_start_key_log

# print(root_frames)

root_frames_sorted = sorted(root_frames.items(), key=lambda x: (int(x[1].split('_')[0])))
# print(root_frames_sorted)
for frame, root_frame in root_frames_sorted:
    # print(frame, root_frame)

    if root_frame == '-1':
        if frame not in frames_of_face:
            frames_of_face[frame] = [frame]
    else:
        if not root_frame in frames_of_face:
            frames_of_face[root_frame] = [root_frame]
        frames_of_face[root_frame].append(frame)


for key, frames_of_face_ in frames_of_face.items():
    frames_of_face[key] = sorted(frames_of_face_, key=lambda x: (int(x.split('_')[0])))
# print(frames_of_face)

frames_of_face_sorted = sorted(frames_of_face.items(), key=lambda x: (int(x[0].split('_')[0])))
for start_frame, frames in frames_of_face_sorted:
    # print(start_frame, frames)
    details = []
    smallest_dist = None
    pid_final = None
    end_frame = None
    for frame in frames:
        value = log_dict[frame]
        pid = value.split('-')[2]
        dist = float(value.split('-')[3])
        details.append('{}::{}::{}'.format(frame, pid, dist))
        if smallest_dist is None:
            smallest_dist = dist

        # if pid == "Unknown":
        #     if pid_final is None:
        #         pid_final = pid
        #         smallest_dist = dist
        # else:
        #     if pid_final == "Unknown":
        #         pid_final = pid
        #         smallest_dist = dist
        #     elif smallest_dist > dist:
        #         print(frame, pid_final, pid, smallest_dist, dist)
        #         pid_final = pid
        #         smallest_dist = dist

        if (pid_final is None) or ((pid_final != "Unknown" and pid != "Unknown") and smallest_dist > dist) or (pid_final == "Unknown" and pid != "Unknown"):
            pid_final = pid
            smallest_dist = dist

        end_frame = frame
    log_temp_debug.append('{} - {}'.format(start_frame, details))

    start_frame_num = int(start_frame.split('_')[0])
    end_frame_num = int(end_frame.split('_')[0])

    if pid_final == "Unknown":
        # log.append('[{}]-[{}]::{}'.format(frame_time[start_frame_num], frame_time[end_frame_num], pid_final))
        # log_debug.append('{}-{}::[{}]-[{}]::{}'.format(start_frame, end_frame, frame_time[start_frame_num], frame_time[end_frame_num], pid_final))
        log.append('[{}]-[{}]::{}::{}'.format(frame_time[start_frame_num], frame_time[end_frame_num], pid_final, smallest_dist))
        log_debug.append('{}-{}::[{}]-[{}]::{}::{}'.format(start_frame, end_frame, frame_time[start_frame_num], frame_time[end_frame_num], pid_final, smallest_dist))
    else:
        log.append('[{}]-[{}]::{}::{}'.format(frame_time[start_frame_num], frame_time[end_frame_num], pid_final, smallest_dist))
        log_debug.append('{}-{}::[{}]-[{}]::{}::{}'.format(start_frame, end_frame, frame_time[start_frame_num], frame_time[end_frame_num], pid_final, smallest_dist))

fw = open(filepath.replace('log.txt', 'log_final.txt'), 'w+')
fw.write('\n'.join(log))
fw = open(filepath.replace('log.txt', 'log_final_debug.txt'), 'w+')
fw.write('\n'.join(log_debug))
fw = open(filepath.replace('log.txt', 'log_temp_debug.txt'), 'w+')
fw.write('\n'.join(log_temp_debug))
